import requests
import json

def debug_map_data():
    """调试地图数据和省份匹配问题"""
    
    # 设备GPS坐标
    device_lat = 27.012345
    device_lon = 109.456789
    
    print(f"[DEBUG] 设备GPS坐标: lat={device_lat}, lon={device_lon}")
    
    # 获取中国地图数据
    try:
        api_url = "https://geojson.cn/api/china/_meta.json"
        response = requests.get(api_url, timeout=10)
        
        if response.status_code == 200:
            meta_data = response.json()
            provinces = meta_data.get('files', [])
            
            print(f"[INFO] 成功获取地图数据，共 {len(provinces)} 个省份")
            
            # 显示所有省份名称
            print("\n[DEBUG] 所有省份名称:")
            for i, province in enumerate(provinces):
                print(f"  {i+1:2d}. {province['name']} (代码: {province['code']})")
            
            # 找到设备所在的省份
            min_distance = float('inf')
            device_province = None
            
            for province in provinces:
                if 'center' in province and len(province['center']) == 2:
                    prov_lon, prov_lat = province['center']
                    distance = ((device_lat - prov_lat) ** 2 + (device_lon - prov_lon) ** 2) ** 0.5
                    if distance < min_distance:
                        min_distance = distance
                        device_province = province['name']
            
            print(f"\n[DEBUG] 设备所在省份: {device_province} (距离: {min_distance:.4f})")
            
            # 检查贵州相关的省份名称
            guizhou_variants = []
            for province in provinces:
                if "贵州" in province['name']:
                    guizhou_variants.append(province['name'])
            
            print(f"\n[DEBUG] 贵州相关省份名称: {guizhou_variants}")
            
            # 检查陕西相关的省份名称
            shaanxi_variants = []
            for province in provinces:
                if "陕西" in province['name']:
                    shaanxi_variants.append(province['name'])
            
            print(f"[DEBUG] 陕西相关省份名称: {shaanxi_variants}")
            
            # 创建地图数据
            map_data = []
            for province in provinces:
                province_name = province['name']
                value = 1 if province_name == device_province else 0
                map_data.append((province_name, value))
            
            # 显示高亮的省份
            highlighted = [item for item in map_data if item[1] == 1]
            print(f"\n[DEBUG] 高亮省份: {highlighted}")
            
            # 检查贵州数据
            guizhou_data = [item for item in map_data if "贵州" in item[0]]
            print(f"[DEBUG] 贵州数据: {guizhou_data}")
            
            # 检查陕西数据
            shaanxi_data = [item for item in map_data if "陕西" in item[0]]
            print(f"[DEBUG] 陕西数据: {shaanxi_data}")
            
            return True
            
        else:
            print(f"[ERROR] API请求失败: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"[ERROR] 调试地图数据时出错: {e}")
        return False

if __name__ == "__main__":
    print("=== 调试地图数据和省份匹配问题 ===")
    success = debug_map_data()
    if success:
        print("\n[SUCCESS] 调试完成")
    else:
        print("\n[FAILED] 调试失败") 
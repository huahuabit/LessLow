#include "bc26.h"
#include "string.h"
#include "usart.h"
#include "delay.h"
#include <string.h>
#include <stdio.h>
#include "usart3.h"
#include "Launch.h"

/*
应该修改的地方
#define token version=2018-10-31&res=products%2Fz50mqDAtBZ%2Fdevices%2Ftest&et=1816664576&method=md5&sign=AfTSdxUONHfhr5%2F80Uox%2Bw%3D%3D
#define PID     z50mqDAtBZ     //产品ID
#define DeviceID test           //设备ID
*/

char *strx,*extstrx;
extern unsigned char  RxBuffer[255],RxCounter;

char topic[] = "$sys/z50mqDAtBZ/test/dp/post/json";
extern char message[];

void Clear_Buffer(void)//清空缓存
{
		u8 i;
		for(i=0;i<255;i++)
		RxBuffer[i]=0;//缓存
		RxCounter=0;
}

//发送AT指令，
void BC26_SendCmd(char *cmd)
{
	Usart3_SendString((unsigned char *)cmd, strlen((const char *)cmd));
}

void BC26_Init(void)
{
    BC26_SendCmd("AT\r\n"); 
    delay_ms(300);
    strx=strstr((const char*)RxBuffer,(const char*)"OK");////返回OK
    Clear_Buffer();	//----------------------
    while(strx==NULL)
    {
        Clear_Buffer();	//----------------------
        BC26_SendCmd("AT\r\n"); 
        delay_ms(300);
        strx=strstr((const char*)RxBuffer,(const char*)"OK");//返回OK
    }

    BC26_SendCmd("AT+QSCLK=0\r\n");   //禁止休眠
    delay_ms(300);
    BC26_SendCmd("AT+CFUN=1\r\n");    //打开全功能模式
    delay_ms(300);
    BC26_SendCmd("AT+CIMI\r\n");   //获取卡号，类似是否存在卡的意思，比较重要
    delay_ms(300);
    strx=strstr((const char*)RxBuffer,(const char*)"460");//返460，表明识别到卡了
		
    Clear_Buffer();	//----------------------
    while(strx==NULL)
			{
					Clear_Buffer();	//----------------------
					BC26_SendCmd("AT+CIMI\r\n");//获取卡号，类似是否存在卡的意思，比较重要。
					delay_ms(300);
					strx=strstr((const char*)RxBuffer,(const char*)"460");//返回OK,说明卡是存在的
			}
					BC26_SendCmd("AT+CGATT=1\r\n");//激活网络，PDP
					delay_ms(300);
					strx=strstr((const char*)RxBuffer,(const char*)"OK");//返OK
					Clear_Buffer();	//----------------------
					BC26_SendCmd("AT+CGATT?\r\n");//查询激活状态
					delay_ms(300);
					strx=strstr((const char*)RxBuffer,(const char*)"+CGATT: 1");//返1
					Clear_Buffer();	//----------------------
		while(strx==NULL)
			{
					Clear_Buffer();	//----------------------
					BC26_SendCmd("AT+CGATT?\r\n");//获取激活状态
					delay_ms(300);
					strx=strstr((const char*)RxBuffer,(const char*)"+CGATT: 1");//返回1,表明注网成功
			}
			BC26_SendCmd("AT+CSQ\r\n");//查看获取CSQ值
			delay_ms(300);
			Clear_Buffer();	//----------------------
}


void MQTT_Init(void)
{
    BC26_SendCmd("AT+QMTCFG=\"version\",0,4\r\n"); //设备版本
    delay_ms(500);
    BC26_SendCmd("AT+QMTCLOSE=0\r\n");//断开与MQTT服务器的连接  
    delay_ms(500);
    Clear_Buffer(); //----------------------
   // BC26_SendCmd("AT+QMTOPEN=0,\"mqtts.heclouds.com\",1883\r\n");//连接MQTT服务器     这里是移动
    BC26_SendCmd("AT+QMTOPEN=0,\"2000568791.non-nb.ctwing.cn\",1883\r\n");//连接MQTT服务器     这里是电信
    delay_ms(500);
    strx=strstr((const char*)RxBuffer,(const char*)"+QMTOPEN: 0,0");//看下返回状态
	printf("BC26 connectting......\r\n");
    while(strx==NULL)
    { 
        strx=strstr((const char*)RxBuffer,(const char*)"+QMTOPEN: 0,0");//通过TCP方式去连接MQTT服务器
    }
    printf("NBiot connect Success!\r\n");
    Clear_Buffer(); //----------------------
    //BC26_SendCmd("AT+QMTCONN=0,\"DeviceID\",\"PID\",\"token\"\r\n");
    //BC26_SendCmd("AT+QMTCONN=0,\"test\",\"z50mqDAtBZ\",\"version=2018-10-31&res=products%2Fz50mqDAtBZ%2Fdevices%2Ftest&et=1816664576&method=md5&sign=AfTSdxUONHfhr5%2F80Uox%2Bw%3D%3D\"\r\n");
    BC26_SendCmd("AT+QMTCONN=0,\"17239913001\",\"tset\",\"yXA96MhrudhknVUq_L_y8BclHiivOtSh6qTYXVIMLuI\"\r\n");   //电信
    delay_ms(500);
    strx=strstr((const char*)RxBuffer,(const char*)"+QMTCONN: 0,0,0");//看下返回状态
    while(strx==NULL)
    {
        strx=strstr((const char*)RxBuffer,(const char*)"+QMTCONN: 0,0,0");//看下返回状态
    }
    Clear_Buffer(); 
}

void MQTT_Publish(char *topic, char *msg) 
{
    char cmd[512];
    
    // 构造AT指令
    sprintf(cmd, "AT+QMTPUB=0,0,0,0,\"%s\"\r\n", topic);
    
    // 发送AT指令
    BC26_SendCmd(cmd);
    delay_ms(300);
    
    // 等待模块响应 ">"
    strx = strstr((const char*)RxBuffer, (const char*)">");
    Clear_Buffer();
    
    if(strx != NULL) {
        // 发送消息内容
        BC26_SendCmd(msg);
        // 发送结束符 Ctrl+Z (0x1A)
        Usart3_SendByte(0x1A);
        delay_ms(500);
        
        // 检查发布是否成功
        strx = strstr((const char*)RxBuffer, (const char*)"+QMTPUB: 0,0,0");
        if(strx == NULL) {
            printf("Publish failed!\r\n");
        } else {
            printf("Publish success!\r\n");
        }
    } 
    else {
        printf("Failed to enter publish mode!\r\n");
    }
    Clear_Buffer();
}


/*

{
  "version": "1.0",
  "profile": {
    "industryId": "1",
    "sceneId": "14",
    "categoryId": "342",
    "productId": "dR7NG4qg4h"
  },
  "properties": [
    {
      "identifier": "E_W",
      "name": "东西半球",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "string",
        "specs": {
          "length": 10
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "N_S",
      "name": "南北半球",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "string",
        "specs": {
          "length": 10
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "UTCTime",
      "name": "UTCTime",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "string",
        "specs": {
          "length": 100
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "angle_x",
      "name": "x加速度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "-10000",
          "step": "0.01",
          "unit": "克 / g"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "angle_y",
      "name": "y加速度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "-10000",
          "step": "0.001",
          "unit": "克 / g"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "angle_z",
      "name": "z加速度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "-10000",
          "step": "0.001",
          "unit": "克 / g"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "displacement_x",
      "name": "x振动位移",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "100000",
          "min": "-100000",
          "step": "0.01",
          "unit": "微米 / μm"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "displacement_y",
      "name": "y振动位移",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "100000",
          "min": "-100000",
          "step": "0.001",
          "unit": "微米 / μm"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "displacement_z",
      "name": "z振动位移",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "100000",
          "min": "-100000",
          "step": "0.001",
          "unit": "微米 / μm"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "frequency_x",
      "name": "x振动频率",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "0",
          "step": "0.001",
          "unit": "赫兹 / Hz"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "frequency_y",
      "name": "y振动频率",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "0",
          "step": "0.001",
          "unit": "赫兹 / Hz"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "frequency_z",
      "name": "z振动频率",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "0",
          "step": "0.001",
          "unit": "赫兹 / Hz"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "gas",
      "name": "空气阻力",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "0",
          "step": "0.01",
          "unit": "欧姆 / Ω"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "humi",
      "name": "温度湿度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "100",
          "min": "0",
          "step": "0.01",
          "unit": "相对湿度 / %RH"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "lat",
      "name": "纬度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "90",
          "min": "0",
          "step": "0.000001",
          "unit": "度 / °"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "lon",
      "name": "经度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "180",
          "min": "0",
          "step": "0.000001",
          "unit": "度 / °"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "pres",
      "name": "大气压强",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "150000",
          "min": "0",
          "step": "0.01",
          "unit": "帕斯卡 / Pa"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "sen0209",
      "name": "柔性压电传感器",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "int32",
        "specs": {
          "max": "6000",
          "min": "0",
          "step": "1",
          "unit": ""
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "speed_x",
      "name": "X轴震动速度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "-10000",
          "step": "0.001",
          "unit": "毫米每秒 / mm/s"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "speed_y",
      "name": "y轴振动速度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "-10000",
          "step": "0.001",
          "unit": "毫米每秒 / mm/s"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "speed_z",
      "name": "z轴振动速度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "10000",
          "min": "-10000",
          "step": "0.001",
          "unit": "毫米每秒 / mm/s"
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "tel0132",
      "name": "震动传感器",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "int32",
        "specs": {
          "max": "6000",
          "min": "0",
          "step": "1",
          "unit": ""
        }
      },
      "functionMode": "property",
      "required": false
    },
    {
      "identifier": "temp",
      "name": "环境温度",
      "functionType": "u",
      "accessMode": "rw",
      "desc": "",
      "dataType": {
        "type": "float",
        "specs": {
          "max": "100",
          "min": "-30",
          "step": "0.01",
          "unit": "摄氏度 / °C"
        }
      },
      "functionMode": "property",
      "required": false
    }
  ],
  "events": [],
  "services": [],
  "combs": []
}
  */
#include "stm32f10x.h"                  // Device header
#include "Timer1.h"
#include "usart.h"
#include "usart3.h"
#include "Delay.h"
#include "adc.h"
#include "stdbool.h"
#include "Timer1.h"
#include "Gps.h"
#include "usart4.h"
#include "bme680.h"
#include "MySPI.h"
#include "PWR.h"
#include "sys.h"
#include "MyRTC.h"
#include "sys.h"
#include "led.h"
#include "lcd.h"
#include "usmart.h"
#include "malloc.h"
#include "sdio_sdcard.h"
#include "w25qxx.h"
#include "ff.h"
#include "exfuns.h"
#include "text.h"
#include "Timer2.h"
#include "Launch.h"
#include "usart2.h"
#include "wit_c_sdk.h"
#include "Timer3.h"
#include "bc26.h"

// #define MAX_POINTS 100 // 最多显示30个点
extern uint16_t adc_0209;
extern uint16_t adc_0132;
// extern u16 temperature_data[MAX_POINTS];
// extern u16 data_count;
// extern const char *x_labels[];
// extern const char *y_labels[];

extern float temp,pres,humi,gas;
extern float lat,lon;
extern char UTCTime;
extern float speed_x, speed_y, speed_z,angle_x, angle_y, angle_z,displacement_x, displacement_y, displacement_z,frequency_x, frequency_y, frequency_z;

extern u16 Read_sign;
extern char topic[];


void Timer1_Init(void)
{
	 // 1. 使能TIM1时钟（APB2总线）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

    // 2. 配置内部时钟源
    TIM_InternalClockConfig(TIM1);

    // 3. 时基单元配置（72MHz系统时钟下，1秒周期）
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;          // 时钟分频（无分频）
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;      // 向上计数
    TIM_TimeBaseInitStruct.TIM_Period = 9999;                         // 自动重装值（0~9999，共10000次计数）
    TIM_TimeBaseInitStruct.TIM_Prescaler = 7199;                      // 预分频（7200分频，72MHz/7200=10kHz）
    TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;                 // 重复计数（高级定时器专用）
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseInitStruct);                  // 初始化时基

    // 4. 清除初始更新标志
    TIM_ClearFlag(TIM1, TIM_FLAG_Update);

    // 5. 使能更新中断（注意高级定时器需要额外使能）
    TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
    TIM_CtrlPWMOutputs(TIM1, ENABLE);  // 高级定时器必须开启主输出

    // 6. NVIC配置
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = TIM1_UP_IRQn;                  // TIM1更新中断通道
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;           // 较高优先级
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStruct);

    // 7. 启动定时器（高级定时器需要额外操作）
    TIM_Cmd(TIM1, ENABLE);
		
}

void TIM1_UP_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
    {
        if (Read_sign == 2)
        {
            //char message[] = "{\"id\":123,\"dp\":{\"temp\":[{\"v\":%f}],\"humi\":[{\"v\":%f}],\"tel0132\":[{\"v\":%d}}]}}";
            char message[1024];  // 确保足够大，防止溢出

            sprintf(message,
                "{"
                "\"id\":%d,"  // 设备ID
                "\"dp\":{"
                    "\"N_S\":[{\"v\":\"%s\"}],"  // 北纬/南纬（字符串）
                    "\"E_W\":[{\"v\":\"%s\"}],"  // 东经/西经（字符串）
                    "\"tel0132\":[{\"v\":%d}],"  // 设备编号（整数）
                    "\"sen0209\":[{\"v\":%d}],"  // 传感器编号（整数）
                    "\"UTCTime\":[{\"v\":%d}],"  // UTC时间戳（整数）
                    "\"latitude\":[{\"v\":%.6f}],"  // 纬度（6位小数）
                    "\"longitude\":[{\"v\":%.6f}],"  // 经度（6位小数）
                    "\"temp\":[{\"v\":%.2f}],"  // 温度（2位小数）
                    "\"pres\":[{\"v\":%.2f}],"  // 气压（2位小数）
                    "\"humi\":[{\"v\":%.2f}],"  // 湿度（2位小数）
                    "\"gas\":[{\"v\":%.2f}],"  // 气体浓度（2位小数）
                    "\"speed_x\":[{\"v\":%.3f}],\"speed_y\":[{\"v\":%.3f}],\"speed_z\":[{\"v\":%.3f}],"  // 三轴速度（3位小数）
                    "\"angle_x\":[{\"v\":%.3f}],\"angle_y\":[{\"v\":%.3f}],\"angle_z\":[{\"v\":%.3f}],"  // 三轴角度（3位小数）
                    "\"displacement_x\":[{\"v\":%.3f}],\"displacement_y\":[{\"v\":%.3f}],\"displacement_z\":[{\"v\":%.3f}],"  // 三轴位移（3位小数）
                    "\"frequency_x\":[{\"v\":%.3f}],\"frequency_y\":[{\"v\":%.3f}],\"frequency_z\":[{\"v\":%.3f}]"  // 三轴频率（3位小数）
                "}"
                "}",
                // 填入实际变量
                123,  // id
                Save_Data.N_S,  // N_S（字符串）
                Save_Data.E_W,  // E_W（字符串）
                tel0132,  // 
                sen0209,  // 
                UTCTime,  // UTC时间
                lat,  // 纬度
                lon,  // 经度
                temp,  // 温度
                pres,  // 气压
                humi,  // 湿度
                gas,  // 气体浓度
                speed_x, speed_y, speed_z,  // 三轴速度
                angle_x, angle_y, angle_z,  // 三轴角度
                displacement_x, displacement_y, displacement_z,  // 三轴位移
                frequency_x, frequency_y, frequency_z  // 三轴频率
            );

             MQTT_Publish(topic, message);
            Read_sign = 0;
            printf("Datas have been loadup!\r\n");
            //BC26_SendCmd("AT+QMTPUB=0,0,0,0,'up','{\"temp\":52.133,\"humi\":52.105}'\r\n");
            Delay_ms(10);
            // Read_sign = 0;
        }
        TIM_ClearITPendingBit(TIM1, TIM_IT_Update);  // 清除中断标志
        // 高级定时器必须清除BDTR寄存器的MOE位相关标志（如果使用PWM输出）
        TIM_ClearFlag(TIM1, TIM_FLAG_Trigger);
    }
}



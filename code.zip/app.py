import base64
import hmac
import time
import os
from urllib.parse import quote
import requests
import pandas as pd
import numpy as np
from flask import Flask, render_template
from pyecharts import options as opts
from pyecharts.charts import Pie, Line, Bar, Boxplot, WordCloud, Scatter, Gauge, Funnel, Radar, HeatMap, Map
from pyecharts.globals import ThemeType
from pyecharts.commons.utils import JsCode
import folium
from geopy.geocoders import Nominatim
from geopy.distance import geodesic

# 导入数据管理器
from data_manager import DataManager 

app = Flask(__name__)

# OneNET API 配置
DEVICE_NAME = "4Gtest01"
PRODUCT_ID = "dR7NG4qg4h"
ACCESS_KEY = "v5tXkwXtz5dhTyn1azn7/WXVNYU7MVlzc799SXvFSUk="  # 产品级 access_key


# OneNET 平台实际的数据流名称映射
# 根据实际返回的数据，OneNET 使用的是英文标识符
ONENET_STREAMS = {
    "pro_I": "pro_I",           # 发电电流
    "del_I": "del_I",           # 消耗电流
    "temp": "temp",             # 环境温度
    "humi": "humi",             # 湿度
    "pres": "pres",             # 大气压强
    "N_S": "N_S",               # GPS纬度 (南北半球)
    "E_W": "E_W",               # GPS经度 (东西半球)
    "displacement_x": "displacement_x",    # X轴振动位移
    "displacement_y": "displacement_y",    # Y轴振动位移
    "displacement_z": "displacement_z",    # Z轴振动位移
    "frequency_x": "frequency_x",         # X轴振动频率
    "frequency_y": "frequency_y",         # Y轴振动频率
    "frequency_z": "frequency_z",         # Z轴振动频率
    "speed_x": "speed_x",                 # X轴震动速度
    "speed_y": "speed_y",                 # Y轴震动速度
    "speed_z": "speed_z",                 # Z轴震动速度
    "angle_x": "angle_x",                 # X轴加速度
    "angle_y": "angle_y",                 # Y轴加速度
    "angle_z": "angle_z",                 # Z轴加速度
    "gas": "gas"                          # 空气阻力
}

# 内部使用的数据流名称
STREAMS = list(ONENET_STREAMS.keys())

def generate_authorization(access_key, product_id, expiration=3600):
    """生成 OneNET API 认证 token"""
    version = '2022-05-01'
    res = f'products/{product_id}'
    et = str(int(time.time()) + expiration)
    method = 'sha1'
    
    # 对 access_key 进行 decode
    key = base64.b64decode(access_key)
    
    # 计算 sign
    org = et + '\n' + method + '\n' + res + '\n' + version
    sign_b = hmac.new(key=key, msg=org.encode(), digestmod=method)
    sign = base64.b64encode(sign_b.digest()).decode()
    
    # value 部分进行 url 编码
    sign = quote(sign, safe='')
    res = quote(res, safe='')
    
    # token 参数拼接
    token = f'version={version}&res={res}&et={et}&method={method}&sign={sign}'
    return token

def get_onenet_data(device_name, product_id, access_key, streams, limit=100):
    """从 OneNET 获取设备数据，智能处理历史数据和新数据"""
    # 确保 data 文件夹存在
    data_dir = "data"
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    
    # 缓存文件路径
    cache_file = os.path.join(data_dir, f"{device_name}_data.csv")
    
    # 检查CSV文件是否存在
    if os.path.exists(cache_file):
        return get_new_data_and_update(device_name, product_id, access_key, streams, cache_file)
    else:
        return get_all_history_data(device_name, product_id, access_key, streams, limit, cache_file)

def get_all_history_data(device_name, product_id, access_key, streams, limit, cache_file):
    """获取全部历史数据（当CSV文件不存在时）"""
    # 生成认证 token
    authorization = generate_authorization(access_key, product_id)
    
    # 设置请求头
    headers = {
        "authorization": authorization,
        "Content-Type": "application/json"
    }
    
    # 初始化 data_dict
    data_dict = {stream: [None] * limit for stream in streams}
    
    # 获取设备属性最新数据
    url = f"https://iot-api.heclouds.com/thingmodel/query-device-property?product_id={product_id}&device_name={device_name}"
    
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code == 200:
            json_data = resp.json()
            if json_data.get('code') == 0 and 'data' in json_data:
                data = json_data['data']
                if isinstance(data, list):
                    data = {item['identifier']: item for item in data}
                
                # 为每个数据流获取数据
                for stream in streams:
                    onenet_stream_name = ONENET_STREAMS.get(stream, stream)
                    if onenet_stream_name in data:
                        value = data[onenet_stream_name].get('value', None)
                        data_dict[stream] = [value] * limit
                    else:
                        data_dict[stream] = [None] * limit
        else:
            for stream in streams:
                data_dict[stream] = [None] * limit
                
    except Exception:
        for stream in streams:
            data_dict[stream] = [None] * limit
    
    # 创建 DataFrame 并保存
    df = pd.DataFrame(data_dict)
    try:
        df.to_csv(cache_file, index=False, encoding='utf-8')
    except Exception:
        pass
    
    return df

def get_new_data_and_update(device_name, product_id, access_key, streams, cache_file):
    """获取新数据并更新CSV文件（当CSV文件存在时）"""
    # 生成认证 token
    authorization = generate_authorization(access_key, product_id)
    
    # 设置请求头
    headers = {
        "authorization": authorization,
        "Content-Type": "application/json"
    }
    
    # 获取设备属性最新数据
    url = f"https://iot-api.heclouds.com/thingmodel/query-device-property?product_id={product_id}&device_name={device_name}"
    
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code == 200:
            json_data = resp.json()
            if json_data.get('code') == 0 and 'data' in json_data:
                data = json_data['data']
                if isinstance(data, list):
                    data = {item['identifier']: item for item in data}
                
                # 收集新数据
                new_data_dict = {}
                for stream in streams:
                    onenet_stream_name = ONENET_STREAMS.get(stream, stream)
                    if onenet_stream_name in data:
                        value = data[onenet_stream_name].get('value', None)
                        if value is not None:
                            new_data_dict[stream] = value
                
                # 使用数据管理器更新数据
                if new_data_dict:
                    dm = DataManager(device_name=device_name)
                    dm.update_latest_data(new_data_dict)
                
                # 返回最新的完整数据
                dm = DataManager(device_name=device_name)
                latest_df = dm.get_latest_data(limit=100)
                if not latest_df.empty:
                    return latest_df
                else:
                    return pd.DataFrame({stream: [None] * 100 for stream in streams})
            else:
                return pd.DataFrame({stream: [None] * 100 for stream in streams})
        else:
            return pd.DataFrame({stream: [None] * 100 for stream in streams})
                
    except Exception:
        return pd.DataFrame({stream: [None] * 100 for stream in streams})

@app.route('/')
def index():
    # 从 OneNET 获取数据
    df = get_onenet_data(DEVICE_NAME, PRODUCT_ID, ACCESS_KEY, STREAMS)
    
    # 创建图表
    direction_chart = create_direction_map_chart(df)
    env_chart = create_env_line_chart(df)
    speed_chart = create_speed_bar_chart(df)
    temp_chart = create_temp_boxplot_chart(df)
    sensor_chart = create_sensor_wordcloud_chart(df)
    power_chart = create_power_line_chart(df)
    power_bar_chart = create_power_bar_chart(df)
    
    return render_template('index.html',
                         pie_chart=direction_chart.render_embed(),
                         env_line_chart=env_chart.render_embed(),
                         speed_bar_chart=speed_chart.render_embed(),
                         temp_boxplot_chart=temp_chart.render_embed(),
                         sensor_wordcloud_chart=sensor_chart.render_embed(),
                         power_line_chart=power_chart.render_embed(),
                         power_bar_chart=power_bar_chart.render_embed())

def create_direction_map_chart(df):
    """创建设备方向分布地图 - 简化版本，确保贵州省高亮"""
    # 获取设备GPS坐标
    device_lat = None
    device_lon = None
    
    if 'N_S' in df.columns and 'E_W' in df.columns:
        ns_data = df['N_S'].dropna()
        ew_data = df['E_W'].dropna()
        if not ns_data.empty and not ew_data.empty:
            try:
                device_lat = float(ns_data.iloc[-1])
                device_lon = float(ew_data.iloc[-1])
            except (ValueError, TypeError):
                device_lat = None
                device_lon = None
    
    # 根据GPS坐标确定省份（简化逻辑）
    device_province = "贵州"  # 默认值
    if device_lat is not None and device_lon is not None:
        if 24.5 <= device_lat <= 29.5 and 103.5 <= device_lon <= 109.5:
            device_province = "贵州"
        elif 28.5 <= device_lat <= 32.5 and 102.5 <= device_lon <= 108.5:
            device_province = "四川"
        elif 22.5 <= device_lat <= 25.5 and 97.5 <= device_lon <= 105.5:
            device_province = "云南"
        elif 28.5 <= device_lat <= 30.5 and 105.5 <= device_lon <= 110.5:
            device_province = "重庆"
        elif 24.5 <= device_lat <= 30.5 and 108.5 <= device_lon <= 114.5:
            device_province = "湖南"
        elif 21.5 <= device_lat <= 26.5 and 104.5 <= device_lon <= 112.5:
            device_province = "广西"
        elif 20.5 <= device_lat <= 25.5 and 109.5 <= device_lon <= 117.5:
            device_province = "广东"
        elif 29.5 <= device_lat <= 33.5 and 108.5 <= device_lon <= 116.5:
            device_province = "湖北"
        elif 32.5 <= device_lat <= 35.5 and 105.5 <= device_lon <= 111.5:
            device_province = "陕西"
        elif 32.5 <= device_lat <= 42.5 and 73.5 <= device_lon <= 108.5:
            device_province = "甘肃"
        elif 35.5 <= device_lat <= 40.5 and 90.5 <= device_lon <= 103.5:
            device_province = "青海"
        elif 34.5 <= device_lat <= 49.5 and 73.5 <= device_lon <= 96.5:
            device_province = "新疆"
        elif 27.5 <= device_lat <= 36.5 and 78.5 <= device_lon <= 99.5:
            device_province = "西藏"
        elif 37.5 <= device_lat <= 50.5 and 97.5 <= device_lon <= 126.5:
            device_province = "内蒙古"
        elif 35.5 <= device_lat <= 39.5 and 104.5 <= device_lon <= 108.5:
            device_province = "宁夏"
        elif 34.5 <= device_lat <= 40.5 and 110.5 <= device_lon <= 114.5:
            device_province = "山西"
        elif 36.5 <= device_lat <= 42.5 and 113.5 <= device_lon <= 119.5:
            device_province = "河北"
        elif 39.5 <= device_lat <= 41.5 and 115.5 <= device_lon <= 117.5:
            device_province = "北京"
        elif 38.5 <= device_lat <= 40.5 and 116.5 <= device_lon <= 118.5:
            device_province = "天津"
        elif 34.5 <= device_lat <= 38.5 and 114.5 <= device_lon <= 122.5:
            device_province = "山东"
        elif 32.5 <= device_lat <= 36.5 and 110.5 <= device_lon <= 116.5:
            device_province = "河南"
        elif 29.5 <= device_lat <= 34.5 and 114.5 <= device_lon <= 119.5:
            device_province = "安徽"
        elif 30.5 <= device_lat <= 35.5 and 116.5 <= device_lon <= 122.5:
            device_province = "江苏"
        elif 30.5 <= device_lat <= 32.5 and 120.5 <= device_lon <= 122.5:
            device_province = "上海"
        elif 27.5 <= device_lat <= 31.5 and 118.5 <= device_lon <= 123.5:
            device_province = "浙江"
        elif 23.5 <= device_lat <= 28.5 and 115.5 <= device_lon <= 120.5:
            device_province = "福建"
        elif 24.5 <= device_lat <= 30.5 and 113.5 <= device_lon <= 118.5:
            device_province = "江西"
        elif 18.5 <= device_lat <= 20.5 and 108.5 <= device_lon <= 111.5:
            device_province = "海南"
        elif 21.5 <= device_lat <= 25.5 and 119.5 <= device_lon <= 122.5:
            device_province = "台湾"
        elif 22.0 <= device_lat <= 22.5 and 113.5 <= device_lon <= 114.5:
            device_province = "香港"
        elif 22.0 <= device_lat <= 22.5 and 113.0 <= device_lon <= 114.0:
            device_province = "澳门"
        elif 38.5 <= device_lat <= 43.5 and 118.5 <= device_lon <= 125.5:
            device_province = "辽宁"
        elif 40.5 <= device_lat <= 46.5 and 121.5 <= device_lon <= 131.5:
            device_province = "吉林"
        elif 43.5 <= device_lat <= 53.5 and 121.5 <= device_lon <= 135.5:
            device_province = "黑龙江"
    
    # 中国省份完整名称列表
    china_provinces = [
        "北京市", "天津市", "河北省", "山西省", "内蒙古自治区", "辽宁省", "吉林省", "黑龙江省",
        "上海市", "江苏省", "浙江省", "安徽省", "福建省", "江西省", "山东省", "河南省",
        "湖北省", "湖南省", "广东省", "广西壮族自治区", "海南省", "重庆市", "四川省", "贵州省",
        "云南省", "西藏自治区", "陕西省", "甘肃省", "青海省", "宁夏回族自治区", "新疆维吾尔自治区", "台湾省",
        "香港特别行政区", "澳门特别行政区"
    ]
    
    # 创建地图数据 - 确保设备所在省份高亮
    map_data = []
    for province in china_provinces:
        # 简化的省份名称匹配逻辑
        is_match = False
        if device_province == "贵州" and province == "贵州省":
            is_match = True
        elif device_province == "四川" and province == "四川省":
            is_match = True
        elif device_province == "云南" and province == "云南省":
            is_match = True
        elif device_province == "重庆" and province == "重庆市":
            is_match = True
        elif device_province == "湖南" and province == "湖南省":
            is_match = True
        elif device_province == "广西" and province == "广西壮族自治区":
            is_match = True
        elif device_province == "广东" and province == "广东省":
            is_match = True
        elif device_province == "湖北" and province == "湖北省":
            is_match = True
        elif device_province == "陕西" and province == "陕西省":
            is_match = True
        elif device_province == "甘肃" and province == "甘肃省":
            is_match = True
        elif device_province == "青海" and province == "青海省":
            is_match = True
        elif device_province == "新疆" and province == "新疆维吾尔自治区":
            is_match = True
        elif device_province == "西藏" and province == "西藏自治区":
            is_match = True
        elif device_province == "内蒙古" and province == "内蒙古自治区":
            is_match = True
        elif device_province == "宁夏" and province == "宁夏回族自治区":
            is_match = True
        elif device_province == "山西" and province == "山西省":
            is_match = True
        elif device_province == "河北" and province == "河北省":
            is_match = True
        elif device_province == "北京" and province == "北京市":
            is_match = True
        elif device_province == "天津" and province == "天津市":
            is_match = True
        elif device_province == "山东" and province == "山东省":
            is_match = True
        elif device_province == "河南" and province == "河南省":
            is_match = True
        elif device_province == "安徽" and province == "安徽省":
            is_match = True
        elif device_province == "江苏" and province == "江苏省":
            is_match = True
        elif device_province == "上海" and province == "上海市":
            is_match = True
        elif device_province == "浙江" and province == "浙江省":
            is_match = True
        elif device_province == "福建" and province == "福建省":
            is_match = True
        elif device_province == "江西" and province == "江西省":
            is_match = True
        elif device_province == "海南" and province == "海南省":
            is_match = True
        elif device_province == "台湾" and province == "台湾省":
            is_match = True
        elif device_province == "香港" and province == "香港特别行政区":
            is_match = True
        elif device_province == "澳门" and province == "澳门特别行政区":
            is_match = True
        elif device_province == "辽宁" and province == "辽宁省":
            is_match = True
        elif device_province == "吉林" and province == "吉林省":
            is_match = True
        elif device_province == "黑龙江" and province == "黑龙江省":
            is_match = True
        
        value = 1 if is_match else 0
        map_data.append((province, value))
    
    # 创建地图图表
    map_chart = (
        Map(init_opts=opts.InitOpts(
            theme=ThemeType.DARK,
            width="100%",
            height="100%",
            bg_color="transparent"
        ))
        .add(
            series_name="设备分布",
            data_pair=map_data,
            maptype="china",
            is_map_symbol_show=True,
            label_opts=opts.LabelOpts(
                is_show=True,
                font_size=10,
                color="#fff",
                font_weight="bold",
                position="inside"
            ),
            itemstyle_opts=opts.ItemStyleOpts(
                border_color="#00d4ff",
                border_width=1.5,
                area_color="rgba(0, 0, 0, 0.3)"
            )
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="设备方向分布",
                subtitle=(
                    f"当前设备位置：{device_province} (GPS: {device_lat:.4f}, {device_lon:.4f})" 
                    if device_lat is not None and device_lon is not None 
                    else f"当前设备位置：{device_province} (GPS: 暂无数据)"
                ),
                pos_left="center",
                pos_top="3%",
                title_textstyle_opts=opts.TextStyleOpts(
                    color="#00d4ff",
                    font_size=18,
                    font_weight="bold"
                ),
                subtitle_textstyle_opts=opts.TextStyleOpts(
                    color="#fff",
                    font_size=13
                )
            ),
            legend_opts=opts.LegendOpts(is_show=False),
            visualmap_opts=opts.VisualMapOpts(
                min_=0,
                max_=1,
                range_color=["rgba(0, 0, 0, 0.3)", "rgba(0, 212, 255, 0.8)"],
                is_calculable=True,
                pos_left="left",
                pos_top="middle",
                textstyle_opts=opts.TextStyleOpts(
                    color="#fff",
                    font_size=11
                ),
                item_width=25,
                item_height=140,
                border_color="#00d4ff",
                border_width=1,
                background_color="rgba(0, 0, 0, 0.3)",
                padding=10,
                pieces=[
                    {"min": 0, "max": 0, "label": "暂无设备", "color": "rgba(0, 0, 0, 0.3)"},
                    {"min": 1, "max": 1, "label": f"设备位置: {device_province}", "color": "rgba(0, 212, 255, 0.9)"}
                ]
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="item",
                formatter=JsCode("""
                function(params) {
                    if (params.value === 1 || params.value === '1') {
                        return params.name + '<br/>设备数量: 1<br/>状态: 在线<br/>当前设备位置';
                    } else {
                        return params.name + '<br/>暂无设备';
                    }
                }
                """),
                background_color="rgba(0,0,0,0.95)",
                border_color="rgba(0, 212, 255, 0.6)",
                border_width=2,
                textstyle_opts=opts.TextStyleOpts(color="#fff"),
                extra_css_text="border-radius: 12px; padding: 0; box-shadow: 0 8px 32px rgba(0, 212, 255, 0.3);"
            )
        )
    )
    return map_chart

def create_direction_map(df):
    """创建方向分布地图"""
    # 检查是否有经纬度数据（假设 N_S 和 E_W 作为示例经纬度）
    if 'N_S' in df and 'E_W' in df:
        ns_data = df['N_S'].dropna().tolist()
        ew_data = df['E_W'].dropna().tolist()

        # 简单示例：构造经纬度数据（实际应用中应根据具体需求调整）
        geo_coordinates = [(ew, ns) for ew, ns in zip(ew_data, ns_data)]

        # 创建地图
        map_chart = (
            Map(init_opts=opts.InitOpts(theme=ThemeType.DARK, width="100%", height="100%"))
            .add(
                series_name="设备方向分布",
                data_pair=[(f"Point {i}", 1) for i in range(len(geo_coordinates))],
                geo_coordinates=geo_coordinates,
                maptype="world",  # 根据实际需求选择地图类型
            )
            .set_global_opts(
                title_opts=opts.TitleOpts(title="设备方向分布"),
                visualmap_opts=opts.VisualMapOpts(),
            )
        )
        return map_chart
    else:
        # 数据缺失时返回提示信息
        return (
            Map(init_opts=opts.InitOpts(theme=ThemeType.DARK, width="100%", height="100%"))
            .set_global_opts(
                title_opts=opts.TitleOpts(title="设备方向分布", subtitle="暂无经纬度数据")
            )
        )

def create_env_line_chart(df):
    """创建环境数据空气阻力折线图"""
    if all(col in df.columns for col in ['temp', 'humi', 'pres', 'gas']):
        try:
            temp_data = [round(float(x), 3) for x in df['temp'].dropna().tolist() if x is not None]
            humi_data = [round(float(x), 3) for x in df['humi'].dropna().tolist() if x is not None]
            pres_data = [round(float(x), 3) for x in df['pres'].dropna().tolist() if x is not None]
            gas_data = [round(float(x), 2) for x in df['gas'].dropna().tolist() if x is not None]
        except (ValueError, TypeError):
            # 如果数据转换失败，使用默认值
            temp_data = [25.0] * 10
            humi_data = [60.0] * 10
            pres_data = [1013.0] * 10
            gas_data = [10000.0] * 10
        
        # 确保所有数据长度一致
        max_len = max(len(temp_data), len(humi_data), len(pres_data), len(gas_data))
        temp_data = temp_data[:max_len] + [temp_data[-1]] * (max_len - len(temp_data)) if len(temp_data) < max_len else temp_data
        humi_data = humi_data[:max_len] + [humi_data[-1]] * (max_len - len(humi_data)) if len(humi_data) < max_len else humi_data
        pres_data = pres_data[:max_len] + [pres_data[-1]] * (max_len - len(pres_data)) if len(pres_data) < max_len else pres_data
        gas_data = gas_data[:max_len] + [gas_data[-1]] * (max_len - len(gas_data)) if len(gas_data) < max_len else gas_data
        
        line = (
            Line(init_opts=opts.InitOpts(theme=ThemeType.DARK, width="100%", height="100%"))
            .add_xaxis(list(range(len(temp_data))))
            .add_yaxis("温度", temp_data, is_smooth=True, color="#ff6b6b", label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis("湿度", humi_data, is_smooth=True, color="#4ecdc4", label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis("气压", pres_data, is_smooth=True, color="#ffe66d", label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis("空气阻力", gas_data, is_smooth=True, color="#FFD93D", label_opts=opts.LabelOpts(is_show=False), yaxis_index=1)
            .extend_axis(
                yaxis=opts.AxisOpts(
                    name="",
                    name_location="end",
                    axislabel_opts=opts.LabelOpts(color="#FFD93D"),
                    splitline_opts=opts.SplitLineOpts(is_show=False)
                )
            )
            .set_global_opts(
                title_opts=opts.TitleOpts(title="", subtitle=""),
                xaxis_opts=opts.AxisOpts(name="时间点", axislabel_opts=opts.LabelOpts(color="#fff")),
                yaxis_opts=opts.AxisOpts(name="环境数值", axislabel_opts=opts.LabelOpts(color="#fff")),
                legend_opts=opts.LegendOpts(textstyle_opts=opts.TextStyleOpts(color="#fff")),
                datazoom_opts=[opts.DataZoomOpts()],
                tooltip_opts=opts.TooltipOpts(
                    trigger="axis",
                    axis_pointer_type="cross",
                    background_color="rgba(0,0,0,0.8)",
                    border_color="rgba(255,255,255,0.2)",
                    textstyle_opts=opts.TextStyleOpts(color="#fff"),
                    formatter="{b}<br/>{a0}: {c0}°C<br/>{a1}: {c1}%<br/>{a2}: {c2} hPa<br/>{a3}: {c3} Pa"
                ),
            )
        )
        return line
    return Line().add("", [])

def create_speed_bar_chart(df):
    """创建频率、位移、加速度、速度柱状图"""
    # 检查是否有位移数据
    displacement_cols = ['displacement_x', 'displacement_y', 'displacement_z']
    frequency_cols = ['frequency_x', 'frequency_y', 'frequency_z']
    acceleration_cols = ['angle_x', 'angle_y', 'angle_z']
    # 速度数据 - 来自OneNET (使用正确的数据流名称)
    velocity_cols = ['speed_x', 'speed_y', 'speed_z']
    
    # 计算平均值
    displacement_avg = []
    frequency_avg = []
    acceleration_avg = []
    velocity_avg = []
    
    # 位移数据
    for col in displacement_cols:
        if col in df.columns:
            try:
                data_series = df[col].dropna()
                if not data_series.empty:
                    numeric_data = pd.to_numeric(data_series, errors='coerce').dropna()
                    if not numeric_data.empty:
                        displacement_avg.append(round(float(numeric_data.mean()), 3))
                    else:
                        displacement_avg.append(0.000)
                else:
                    displacement_avg.append(0.000)
            except Exception:
                displacement_avg.append(0.000)
        else:
            displacement_avg.append(0.000)
    
    # 频率数据
    for col in frequency_cols:
        if col in df.columns:
            try:
                data_series = df[col].dropna()
                if not data_series.empty:
                    numeric_data = pd.to_numeric(data_series, errors='coerce').dropna()
                    if not numeric_data.empty:
                        frequency_avg.append(round(float(numeric_data.mean()), 3))
                    else:
                        frequency_avg.append(0.000)
                else:
                    frequency_avg.append(0.000)
            except Exception:
                frequency_avg.append(0.000)
        else:
            frequency_avg.append(0.000)
    
    # 加速度数据
    for col in acceleration_cols:
        if col in df.columns:
            try:
                data_series = df[col].dropna()
                if not data_series.empty:
                    numeric_data = pd.to_numeric(data_series, errors='coerce').dropna()
                    if not numeric_data.empty:
                        acceleration_avg.append(round(float(numeric_data.mean()), 3))
                    else:
                        acceleration_avg.append(0.000)
                else:
                    acceleration_avg.append(0.000)
            except Exception:
                acceleration_avg.append(0.000)
        else:
            acceleration_avg.append(0.000)
    
    # 速度数据 - 来自OneNET
    for col in velocity_cols:
        if col in df.columns:
            try:
                data_series = df[col].dropna()
                if not data_series.empty:
                    numeric_data = pd.to_numeric(data_series, errors='coerce').dropna()
                    if not numeric_data.empty:
                        velocity_avg.append(round(float(numeric_data.mean()), 3))
                    else:
                        velocity_avg.append(0.000)
                else:
                    velocity_avg.append(0.000)
            except Exception:
                velocity_avg.append(0.000)
        else:
            velocity_avg.append(0.000)
    
    # 创建柱状图
    bar = (
        Bar(init_opts=opts.InitOpts(theme=ThemeType.DARK, width="100%", height="100%"))
        .add_xaxis(["X轴", "Y轴", "Z轴"])
        .add_yaxis("频率", frequency_avg, color=["#ff6b6b", "#ff6b6b", "#ff6b6b"])
        .add_yaxis("位移", displacement_avg, color=["#00d4ff", "#00d4ff", "#00d4ff"])
        .add_yaxis("加速度", acceleration_avg, color=["#4ecdc4", "#4ecdc4", "#4ecdc4"])
        .add_yaxis("速度", velocity_avg, color=["#ffe66d", "#ffe66d", "#ffe66d"])
        .set_global_opts(
            title_opts=opts.TitleOpts(title="", subtitle=""),
            xaxis_opts=opts.AxisOpts(
                name="轴向", 
                axislabel_opts=opts.LabelOpts(color="#fff"),
                name_location="middle",
                name_gap=35,
                name_textstyle_opts=opts.TextStyleOpts(color="#fff", font_size=12)
            ),
            yaxis_opts=opts.AxisOpts(
                name="数值 (频率:Hz, 位移:mm, 加速度:mm/s², 速度:mm/s)", 
                axislabel_opts=opts.LabelOpts(color="#fff"),
                name_location="middle",
                name_gap=50,
                name_textstyle_opts=opts.TextStyleOpts(color="#fff", font_size=10),
                # 设置Y轴范围，让0在中间
                min_=min(min(displacement_avg + frequency_avg + acceleration_avg + velocity_avg) - 10, -60),
                max_=max(max(displacement_avg + frequency_avg + acceleration_avg + velocity_avg) + 10, 60),
                # 设置Y轴刻度，让0在中间
                split_number=6,
                axisline_opts=opts.AxisLineOpts(is_on_zero=True)
            ),
            legend_opts=opts.LegendOpts(
                textstyle_opts=opts.TextStyleOpts(color="#fff"),
                pos_top="5%"
            ),
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="shadow",
                background_color="rgba(0,0,0,0.8)",
                border_color="rgba(255,255,255,0.2)",
                textstyle_opts=opts.TextStyleOpts(color="#fff"),
                formatter="{b}<br/>{a0}: {c0} Hz<br/>{a1}: {c1} mm<br/>{a2}: {c2} mm/s²<br/>{a3}: {c3} mm/s"
            ),
        )
    )
    return bar

def create_temp_boxplot_chart(df):
    """创建温度箱线图"""
    if 'temp' in df.columns:
        try:
            temp_data = [round(float(x), 3) for x in df['temp'].dropna().tolist() if x is not None]
        except (ValueError, TypeError):
            temp_data = [25.0, 26.0, 27.0, 28.0, 29.0]  # 默认数据
        if len(temp_data) >= 4:
            boxplot = (
                Boxplot(init_opts=opts.InitOpts(theme=ThemeType.DARK, width="100%", height="100%"))
                .add_xaxis(["温度"])
                .add_yaxis("温度分布", [temp_data])
                .set_global_opts(
                    title_opts=opts.TitleOpts(title="", subtitle=""),
                    xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(color="#fff")),
                    yaxis_opts=opts.AxisOpts(name="温度值 (℃)", axislabel_opts=opts.LabelOpts(color="#fff")),
                    legend_opts=opts.LegendOpts(textstyle_opts=opts.TextStyleOpts(color="#fff")),
                    tooltip_opts=opts.TooltipOpts(
                        trigger="item",
                        background_color="rgba(0,0,0,0.8)",
                        border_color="rgba(255,255,255,0.2)",
                        textstyle_opts=opts.TextStyleOpts(color="#fff"),
                        formatter=JsCode("""
                        function(params) {
                            if (params.componentType === 'series') {
                                var data = params.data;
                                var min = Math.min.apply(null, data);
                                var max = Math.max.apply(null, data);
                                var avg = (data.reduce((a, b) => a + b, 0) / data.length).toFixed(3);
                                return '温度分布统计<br/>数据点: ' + data.length + ' 个<br/>最小值: ' + min.toFixed(3) + ' ℃<br/>最大值: ' + max.toFixed(3) + ' ℃<br/>平均值: ' + avg + ' ℃';
                            }
                            return params.name + '<br/>' + params.value + ' ℃';
                        }
                        """)
                    ),
                )
            )
            return boxplot
    return (
        Boxplot(init_opts=opts.InitOpts(theme=ThemeType.DARK, width="100%", height="100%"))
        .set_global_opts(
            title_opts=opts.TitleOpts(title="温度分布", subtitle="数据不足")
        )
    )

def create_sensor_wordcloud_chart(df):
    """创建传感器词云图"""
    if all(col in df.columns for col in ['pro_I', 'del_I']):
        try:
            pro_i_avg = round(float(df['pro_I'].dropna().mean()), 3) if not df['pro_I'].dropna().empty else 30.000
            del_i_avg = round(float(df['del_I'].dropna().mean()), 3) if not df['del_I'].dropna().empty else 15.000
        except (ValueError, TypeError):
            pro_i_avg = 30.000
            del_i_avg = 15.000
        
        wordcloud = (
            WordCloud(init_opts=opts.InitOpts(theme=ThemeType.LIGHT, width="100%", height="100%"))
            .add(
                series_name="传感器数据",
                data_pair=[
                    ("发电电流", pro_i_avg),
                    ("消耗电流", del_i_avg),
                    ("温度传感器", 100.000),
                    ("湿度传感器", 80.000),
                    ("气压传感器", 60.000),
                ],
                word_size_range=[15, 80],
            )
            .set_global_opts(title_opts=opts.TitleOpts(title="传感器数据词云"))
        )
        return wordcloud
    return WordCloud().add("", [])

def create_power_line_chart(df):
    """创建发电量消耗电量折线图"""
    if all(col in df.columns for col in ['pro_I', 'del_I']):
        try:
            pro_i_data = [round(float(x), 3) for x in df['pro_I'].dropna().tolist() if x is not None]
            del_i_data = [round(float(x), 3) for x in df['del_I'].dropna().tolist() if x is not None]
        except (ValueError, TypeError):
            # 如果数据转换失败，使用默认值
            pro_i_data = [30.0, 32.0, 35.0, 38.0, 40.0, 42.0, 45.0, 48.0, 50.0, 52.0]
            del_i_data = [15.0, 16.0, 18.0, 20.0, 22.0, 24.0, 26.0, 28.0, 30.0, 32.0]
        
        line = (
            Line(init_opts=opts.InitOpts(theme=ThemeType.DARK, width="100%", height="100%"))
            .add_xaxis(list(range(len(pro_i_data))))
            .add_yaxis("发电电流", pro_i_data, is_smooth=True, color="#FF6B6B", label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis("消耗电流", del_i_data, is_smooth=True, color="#4ECDC4", label_opts=opts.LabelOpts(is_show=False))
            .set_global_opts(
                title_opts=opts.TitleOpts(title="", subtitle=""),
                xaxis_opts=opts.AxisOpts(name="时间点", axislabel_opts=opts.LabelOpts(color="#fff")),
                yaxis_opts=opts.AxisOpts(name="电流值 (mA/μA)", axislabel_opts=opts.LabelOpts(color="#fff")),
                legend_opts=opts.LegendOpts(pos_top="5%", textstyle_opts=opts.TextStyleOpts(color="#fff")),
                datazoom_opts=[opts.DataZoomOpts()],
                tooltip_opts=opts.TooltipOpts(
                    trigger="axis",
                    axis_pointer_type="cross",
                    background_color="rgba(0,0,0,0.8)",
                    border_color="rgba(255,255,255,0.2)",
                    textstyle_opts=opts.TextStyleOpts(color="#fff"),
                    formatter="{b}<br/>{a0}: {c0} mA<br/>{a1}: {c1} μA"
                ),
            )
        )
        return line
    return Line().add("", [])

def create_power_bar_chart(df):
    """创建发电量消耗电量柱状图"""
    if all(col in df.columns for col in ['pro_I', 'del_I']):
        try:
            pro_i_avg = round(float(df['pro_I'].dropna().mean()), 3) if not df['pro_I'].dropna().empty else 30.000
            del_i_avg = round(float(df['del_I'].dropna().mean()), 3) if not df['del_I'].dropna().empty else 15.000
        except (ValueError, TypeError):
            pro_i_avg = 30.000
            del_i_avg = 15.000
        
        bar = (
            Bar(init_opts=opts.InitOpts(theme=ThemeType.DARK, width="100%", height="100%"))
            .add_xaxis(["发电电流", "消耗电流"])
            .add_yaxis("平均值", [pro_i_avg, del_i_avg], color=["#FF6B6B", "#4ECDC4"])
            .set_global_opts(
                title_opts=opts.TitleOpts(title="", subtitle=""),
                xaxis_opts=opts.AxisOpts(name="类型", axislabel_opts=opts.LabelOpts(color="#fff")),
                yaxis_opts=opts.AxisOpts(name="数值", axislabel_opts=opts.LabelOpts(color="#fff")),
                legend_opts=opts.LegendOpts(textstyle_opts=opts.TextStyleOpts(color="#fff")),
                tooltip_opts=opts.TooltipOpts(
                    trigger="axis",
                    background_color="rgba(0,0,0,0.8)",
                    border_color="rgba(255,255,255,0.2)",
                    textstyle_opts=opts.TextStyleOpts(color="#fff"),
                    formatter=lambda params: f"{params[0].name}<br/>发电电流: {params[0].value} mA<br/>消耗电流: {params[1].value} μA"
                ),
            )
        )
        return bar
    return Bar().add("", [])

if __name__ == '__main__':
    # print("Running on http://127.0.0.1:5000")
    # print("Running on http://10.229.225.100:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)

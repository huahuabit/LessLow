// 确保axios已定义
if (typeof axios !== 'undefined') {
    axios.defaults.baseURL = 'http://127.0.0.1:8080';
} else {
    console.error('axios is not defined');
}

// 添加安全检查，确保函数存在再调用
function safeCall(fnName) {
    if (typeof window[fnName] === 'function') {
        window[fnName]();
    } else {
        console.warn(fnName + ' is not defined');
    }
}

// 延迟执行确保资源加载完成
document.addEventListener('DOMContentLoaded', function() {

});
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据管理模块
用于管理 OneNET 数据的 CSV 文件
"""

import os
import pandas as pd
import time
from datetime import datetime

class DataManager:
    def __init__(self, data_dir="data", device_name="4Gtest01"):
        self.data_dir = data_dir
        self.device_name = device_name
        self.csv_file = os.path.join(data_dir, f"{device_name}_data.csv")
        
        # 确保数据目录存在
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
            print(f"[INFO] 创建数据目录: {data_dir}")
    
    def load_existing_data(self):
        """加载现有的CSV数据"""
        if os.path.exists(self.csv_file):
            try:
                df = pd.read_csv(self.csv_file, encoding='utf-8')
                print(f"[INFO] 加载现有数据: {len(df)} 行")
                return df
            except Exception as e:
                print(f"[WARNING] 加载现有数据失败: {e}")
                return pd.DataFrame()
        else:
            print(f"[INFO] CSV文件不存在: {self.csv_file}")
            return pd.DataFrame()
    
    def append_new_data(self, new_data_dict):
        """追加新数据到CSV文件"""
        try:
            # 创建新数据行
            new_row = pd.DataFrame([new_data_dict])
            
            # 加载现有数据
            existing_df = self.load_existing_data()
            
            if existing_df.empty:
                # 如果文件不存在或为空，创建新文件
                new_row.to_csv(self.csv_file, index=False, encoding='utf-8')
                print(f"[INFO] 创建新的CSV文件: {self.csv_file}")
            else:
                # 追加到现有文件
                combined_df = pd.concat([existing_df, new_row], ignore_index=True)
                
                # 限制文件大小，保留最新的1000行
                if len(combined_df) > 1000:
                    combined_df = combined_df.tail(1000)
                    print(f"[INFO] 数据超过1000行，保留最新1000行")
                
                combined_df.to_csv(self.csv_file, index=False, encoding='utf-8')
                print(f"[INFO] 追加新数据到CSV文件: {self.csv_file}")
            
            return True
            
        except Exception as e:
            print(f"[ERROR] 追加数据失败: {e}")
            return False
    
    def update_latest_data(self, new_data_dict):
        """更新最新数据（替换最后一行或添加新行）"""
        try:
            # 加载现有数据
            existing_df = self.load_existing_data()
            
            # 创建新数据行
            new_row = pd.DataFrame([new_data_dict])
            
            if existing_df.empty:
                # 如果文件不存在或为空，创建新文件
                new_row.to_csv(self.csv_file, index=False, encoding='utf-8')
                print(f"[INFO] 创建新的CSV文件: {self.csv_file}")
            else:
                # 检查是否有时间戳列，如果没有则添加
                if 'timestamp' not in existing_df.columns:
                    existing_df['timestamp'] = pd.Timestamp.now()
                
                # 添加时间戳到新数据
                new_row['timestamp'] = pd.Timestamp.now()
                
                # 检查最后一行是否与当前时间相差超过1分钟
                if 'timestamp' in existing_df.columns and len(existing_df) > 0:
                    last_timestamp = pd.to_datetime(existing_df['timestamp'].iloc[-1])
                    current_time = pd.Timestamp.now()
                    time_diff = (current_time - last_timestamp).total_seconds()
                    
                    if time_diff < 60:  # 如果时间差小于1分钟，更新最后一行
                        existing_df.iloc[-1] = new_row.iloc[0]
                        print(f"[INFO] 更新最后一行数据（时间差: {time_diff:.1f}秒）")
                    else:
                        # 时间差大于1分钟，添加新行
                        existing_df = pd.concat([existing_df, new_row], ignore_index=True)
                        print(f"[INFO] 添加新行数据（时间差: {time_diff:.1f}秒）")
                else:
                    # 没有时间戳，直接添加新行
                    existing_df = pd.concat([existing_df, new_row], ignore_index=True)
                    print(f"[INFO] 添加新行数据")
                
                # 限制文件大小，保留最新的1000行
                if len(existing_df) > 1000:
                    existing_df = existing_df.tail(1000)
                    print(f"[INFO] 数据超过1000行，保留最新1000行")
                
                existing_df.to_csv(self.csv_file, index=False, encoding='utf-8')
            
            return True
            
        except Exception as e:
            print(f"[ERROR] 更新数据失败: {e}")
            return False
    
    def get_latest_data(self, limit=100):
        """获取最新的数据"""
        try:
            df = self.load_existing_data()
            if not df.empty:
                return df.tail(limit)
            return df
        except Exception as e:
            print(f"[ERROR] 获取最新数据失败: {e}")
            return pd.DataFrame()
    
    def get_data_summary(self):
        """获取数据摘要"""
        try:
            df = self.load_existing_data()
            if df.empty:
                return "无数据"
            
            summary = {
                "总行数": len(df),
                "列数": len(df.columns),
                "数据流": list(df.columns),
                "最新更新时间": df['timestamp'].iloc[-1] if 'timestamp' in df.columns else "无时间戳"
            }
            
            # 统计每个数据流的有效数据数量
            data_stats = {}
            for col in df.columns:
                if col != 'timestamp':
                    valid_count = df[col].notna().sum()
                    data_stats[col] = f"{valid_count}/{len(df)}"
            
            summary["数据统计"] = data_stats
            
            return summary
            
        except Exception as e:
            print(f"[ERROR] 获取数据摘要失败: {e}")
            return "获取摘要失败"
    
    def clear_old_data(self, days=7):
        """清理旧数据"""
        try:
            df = self.load_existing_data()
            if df.empty or 'timestamp' not in df.columns:
                print("[INFO] 没有时间戳数据，无法清理")
                return False
            
            # 计算截止时间
            cutoff_time = pd.Timestamp.now() - pd.Timedelta(days=days)
            
            # 过滤数据
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            filtered_df = df[df['timestamp'] >= cutoff_time]
            
            if len(filtered_df) < len(df):
                filtered_df.to_csv(self.csv_file, index=False, encoding='utf-8')
                print(f"[INFO] 清理了 {len(df) - len(filtered_df)} 行旧数据")
                return True
            else:
                print("[INFO] 没有需要清理的旧数据")
                return True
                
        except Exception as e:
            print(f"[ERROR] 清理旧数据失败: {e}")
            return False

# 使用示例
if __name__ == "__main__":
    # 创建数据管理器
    dm = DataManager()
    
    # 获取数据摘要
    summary = dm.get_data_summary()
    print("=== 数据摘要 ===")
    print(summary)
    
    # 测试添加新数据
    test_data = {
        'pro_I': 15.678,
        'del_I': 45.321,
        'temp': 30.66,
        'humi': 54.55,
        'pres': 10000.54,
        'N_S': 29.658732,
        'E_W': 109.654832,
        'displacement_x': 123.456,
        'displacement_y': -78.901,
        'displacement_z': 34.567,
        'frequency_x': 60.123,
        'frequency_y': 59.876,
        'frequency_z': 61.234,
        'speed_x': 0.123,
        'speed_y': -0.045,
        'speed_z': 0.067,
        'angle_x': -0.665,
        'angle_y': 1.665,
        'angle_z': 6.254,
        'gas': 9862.36
    }
    
    # 更新数据
    success = dm.update_latest_data(test_data)
    if success:
        print("✅ 数据更新成功")
    else:
        print("❌ 数据更新失败") 
import requests
import json

def debug_province_mapping():
    """调试省份名称映射问题"""
    
    # 设备GPS坐标
    device_lat = 27.012345
    device_lon = 109.456789
    
    print(f"[DEBUG] 设备GPS坐标: lat={device_lat}, lon={device_lon}")
    
    # 获取中国地图数据
    try:
        api_url = "https://geojson.cn/api/china/_meta.json"
        response = requests.get(api_url, timeout=10)
        
        if response.status_code == 200:
            meta_data = response.json()
            print(f"[DEBUG] API返回数据结构: {list(meta_data.keys())}")
            
            # 检查数据结构
            if 'files' in meta_data:
                provinces = meta_data.get('files', [])
                print(f"[INFO] 成功获取地图数据，共 {len(provinces)} 个省份")
                
                # 显示所有省份名称
                print("\n[DEBUG] 所有省份名称:")
                for i, province in enumerate(provinces):
                    if isinstance(province, dict) and 'name' in province:
                        print(f"  {i+1:2d}. {province['name']} (代码: {province.get('code', 'N/A')})")
                    else:
                        print(f"  {i+1:2d}. {province} (非标准格式)")
            else:
                print(f"[ERROR] API返回数据中没有'files'字段")
                print(f"[DEBUG] 完整API响应: {meta_data}")
                return False
            
            # 检查files字段的详细内容并提取省份信息
            if 'files' in meta_data:
                files_data = meta_data['files']
                print(f"\n[DEBUG] files字段内容:")
                if isinstance(files_data, list) and len(files_data) > 0:
                    china_data = files_data[0]  # 第一个元素是中华人民共和国
                    print(f"  中国数据: {china_data.get('name', 'Unknown')}")
                    
                    # 提取省份信息
                    provinces = []
                    if 'children' in china_data:
                        provinces = china_data['children']
                        print(f"  找到 {len(provinces)} 个省份")
                        
                        # 显示省份名称
                        print(f"\n[DEBUG] 省份列表:")
                        for i, province in enumerate(provinces):
                            if isinstance(province, dict) and 'name' in province:
                                print(f"  {i+1:2d}. {province['name']}")
                    else:
                        print(f"  中国数据中没有children字段")
                else:
                    print(f"  files不是列表或为空: {type(files_data)}")
                    print(f"  files内容: {files_data}")
            
            # 找到设备所在的省份
            min_distance = float('inf')
            device_province = None
            
            # 使用简化的省份判断逻辑
            if 24.5 <= device_lat <= 29.5 and 103.5 <= device_lon <= 109.5:
                device_province = "贵州"
            elif 28.5 <= device_lat <= 32.5 and 102.5 <= device_lon <= 108.5:
                device_province = "四川"
            elif 22.5 <= device_lat <= 25.5 and 97.5 <= device_lon <= 105.5:
                device_province = "云南"
            elif 28.5 <= device_lat <= 30.5 and 105.5 <= device_lon <= 110.5:
                device_province = "重庆"
            elif 24.5 <= device_lat <= 30.5 and 108.5 <= device_lon <= 114.5:
                device_province = "湖南"
            elif 21.5 <= device_lat <= 26.5 and 104.5 <= device_lon <= 112.5:
                device_province = "广西"
            elif 20.5 <= device_lat <= 25.5 and 109.5 <= device_lon <= 117.5:
                device_province = "广东"
            elif 29.5 <= device_lat <= 33.5 and 108.5 <= device_lon <= 116.5:
                device_province = "湖北"
            elif 32.5 <= device_lat <= 35.5 and 105.5 <= device_lon <= 111.5:
                device_province = "陕西"
            else:
                device_province = "贵州"  # 默认值
            
            print(f"\n[DEBUG] 设备所在省份: {device_province} (距离: {min_distance:.4f})")
            
            # 检查贵州相关的省份名称
            guizhou_variants = []
            for province in provinces:
                if isinstance(province, dict) and 'name' in province and "贵州" in province['name']:
                    guizhou_variants.append(province['name'])
            
            print(f"\n[DEBUG] 贵州相关省份名称: {guizhou_variants}")
            
            # 检查陕西相关的省份名称
            shaanxi_variants = []
            for province in provinces:
                if isinstance(province, dict) and 'name' in province and "陕西" in province['name']:
                    shaanxi_variants.append(province['name'])
            
            print(f"[DEBUG] 陕西相关省份名称: {shaanxi_variants}")
            
            # 创建地图数据
            map_data = []
            for province in provinces:
                if isinstance(province, dict) and 'name' in province:
                    province_name = province['name']
                    value = 1 if province_name == device_province else 0
                    map_data.append((province_name, value))
            
            # 显示高亮的省份
            highlighted = [item for item in map_data if item[1] == 1]
            print(f"\n[DEBUG] 高亮省份: {highlighted}")
            
            # 检查贵州数据
            guizhou_data = [item for item in map_data if "贵州" in item[0]]
            print(f"[DEBUG] 贵州数据: {guizhou_data}")
            
            # 检查陕西数据
            shaanxi_data = [item for item in map_data if "陕西" in item[0]]
            print(f"[DEBUG] 陕西数据: {shaanxi_data}")
            
            # 检查是否有省份名称不匹配的问题
            print(f"\n[DEBUG] 省份名称匹配检查:")
            print(f"  设备所在省份: '{device_province}'")
            print(f"  贵州相关名称: {guizhou_variants}")
            
            if device_province and guizhou_variants:
                if device_province in guizhou_variants:
                    print(f"  ✓ 匹配成功: '{device_province}' 在贵州相关名称中")
                else:
                    print(f"  ✗ 匹配失败: '{device_province}' 不在贵州相关名称中")
                    print(f"    这可能是导致贵州省无法高亮的原因！")
            
            return True
            
        else:
            print(f"[ERROR] API请求失败: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"[ERROR] 调试省份映射时出错: {e}")
        return False

if __name__ == "__main__":
    print("=== 调试省份名称映射问题 ===")
    success = debug_province_mapping()
    if success:
        print("\n[SUCCESS] 调试完成")
    else:
        print("\n[FAILED] 调试失败") 
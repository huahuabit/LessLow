#ifndef __TEL0132_H
#define __TEL0132_H
void tel0132_init(void);
void tel0132(void);


#endif

#ifndef __PWR_H
#define __PWR_H

#include "stm32f10x.h"

// 模式宏定义
#define SportMode    1
#define SleepMode    2
#define StopMode     3
#define StandbyMode  4

// 外部变量声明
extern uint16_t mode_sign;
extern volatile uint16_t mode;
extern uint16_t sign;

// 函数声明

void RTC_Progress(uint16_t lowpower_mode);

void WKUP_Init(void);
void Disable_Wakeup_Sources(void);

void Enter_SleepMode(void);
void Enter_StopMode(void);
void Enter_StandbyMode(void);

void Mode_Choice(uint16_t mode);
void PWR_Init(void);

#endif 



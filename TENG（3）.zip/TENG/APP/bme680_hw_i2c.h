#ifndef __BME680_HW_I2C_H
#define __BME680_HW_I2C_H
#include "stm32f10x.h"                  // Device header


void BME680_WriteReg(uint8_t RegAddress, uint8_t Data);
uint8_t BME680_ReadReg(uint8_t RegAddress);

void BME680_Init(void);
uint8_t BME680_GetID(void);
void BME680_GetData(int16_t *AccX, int16_t *AccY, int16_t *AccZ, 
						int16_t *GyroX, int16_t *GyroY, int16_t *GyroZ);






#endif







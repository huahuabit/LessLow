#ifndef __ADC_H
#define __ADC_H
#include "stm32f10x.h"                  // Device header

void adc_Init(void);
void ADC_Start_Conversion(void);
uint16_t ADC_Read_PC0(void); // sen0209
uint16_t ADC_Read_PC1(void); // tel0132
void sen0209(void);
void tel0132(void);

#endif




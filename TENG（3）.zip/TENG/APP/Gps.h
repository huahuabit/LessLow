#ifndef __GPS_H
#define __GPS_H

#include "stm32f10x.h"
#include <string.h>
#include <stdio.h>
#include "stdbool.h"

#define GPS_RX_BUFFER_LENGTH 600

typedef struct {
    char GPS_DATA[80];
    bool GetData_Flag;      // 获取到GPS数据标志位
    bool ParseData_Flag;    // 解析完成标志位
    char UTCTime[11];       // UTC时间
    char latitude[11];      // 纬度
    char N_S[2];            // N/S
    char longitude[12];     // 经度
    char E_W[2];            // E/W
    bool Usefull_Flag;      // 定位信息是否有有效标志位
} GPS_Data;

extern GPS_Data Save_Data;
extern char gpsRxBuffer[GPS_RX_BUFFER_LENGTH];
extern unsigned int gpsRxLength;

void GPS_Init(void);
void RST_GpsRxBuffer(void);
void Read_Gps(void);
void parse_GpsDATA(void);
void print_GpsDATA(void);

#endif



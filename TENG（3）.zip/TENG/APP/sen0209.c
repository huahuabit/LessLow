#include "stm32f10x.h"                  // Device header
#include "sen0209.h"
#include "usart1.h"
#include "adc.h"
uint16_t adc_0209;

void sen0209(void)
{
	// ADC数据采集
	adc_0209 = ADC_Read_PC0();

//	// 将采集结果通过串口输出
//	printf("SEN0209: %d\n\r", adc_0209);

}




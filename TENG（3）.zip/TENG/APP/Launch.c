#include "stm32f10x.h"
#include "usart1.h"
#include "usart3.h"
#include "Delay.h"
#include "tel0132.h"
#include "stdbool.h"
#include "Timer1.h"
#include "Timer2.h"
#include "Gps.h"
#include "usart4.h"
#include "bme680.h"
#include "MySPI.h"
#include "PWR.h"
#include "usb_hid.h"
#include "rtc.h"
#include "sys.h"
#include "adc.h"
extern uint16_t adc_0209;
extern uint16_t adc_0132;

HARDWARE_INFO g_hdInfo = {0};			
CALENDAR g_caInfo = {0};				

extern u8 g_bSecFlag;					// 秒中断标志
extern u8 g_bAlarmFlag;
extern CALENDAR g_caInfo;			//日历结构体

void output(void) 		// 打印数据
{
	printf("*********************************************\n\r");
	printf("sen0209:%d   tel0132:%d\n\r",adc_0209,adc_0132);
	Read_Gps();         
	parse_GpsDATA();    
	print_GpsDATA();
	Bme_Data();
}

void SystemClock_Config(void)
{
    // 配置系统时钟为72MHz
    RCC_DeInit();
    RCC_HSEConfig(RCC_HSE_ON);
    RCC_WaitForHSEStartUp();
    
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
    FLASH_SetLatency(FLASH_Latency_2);
    
    RCC_HCLKConfig(RCC_SYSCLK_Div1);
    RCC_PCLK2Config(RCC_HCLK_Div1);
    RCC_PCLK1Config(RCC_HCLK_Div2);
    
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
    RCC_PLLCmd(ENABLE);
    
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
    
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    while(RCC_GetSYSCLKSource() != 0x08);
	
	
}

void All_Init(void)
{
	SystemClock_Config();
	NVIC_Configuration();
	Timer1_Init();    
//	TIM2_Init();		 没有使用
	TIM7_Init();     
	Usart1Init(9600);
	//串口二以后会用到
	GPS_Init(); 
	uart4_Init();    
	adc_Init(); 
	Bme680_Init();
//	lowpower_Init();
//  PWR_Init();
}

////系统进入待机模式
//void Sys_Enter_Standby(void)
//{			 
//	//关闭所有外设
//   	RCC->APB2RSTR|=0X01FC;//复位所有IO口
//	
//		Sys_Standby();//进入待机模式
//}

//void IdleHandle(void)
//{
//	u32 totalSec;
//	
//	while(1)
//	{
//		
//		if (g_bSecFlag)  //每秒计时器
//				{
//						g_bSecFlag = 0;
//						printf("Year:%d,Month:%d,Day:%d,H:%d,M:%d,S:%d\r\n",g_caInfo.year,g_caInfo.month,g_caInfo.date,g_caInfo.time.hour,g_caInfo.time.min,g_caInfo.time.sec);
//					
//					 
//						if(g_caInfo.time.sec==15){
//								
//									totalSec=RTC->CNTH;//得到计数器中的值(秒钟数)
//									totalSec<<=16;
//									totalSec+=RTC->CNTL;
//									printf("totalSec：%d\r\n",totalSec);
//									totalSec+=30;  //standby for 30seconds
//									printf("totalSec：%d\r\n",totalSec);
//							
//									RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);	//使能PWR和BKP外设时钟   
//									PWR_BackupAccessCmd(ENABLE);	//使能后备寄存器访问  
//									//上面三步是必须的!
//									RTC_ITConfig(RTC_IT_ALR, ENABLE);		//使能RTC闹钟中断
//									RTC_SetAlarm(totalSec);
//									RTC_WaitForLastTask();	//等待最近一次对RTC寄存器的写操作完成  	
//	
//								
//									printf("Set Alarm Success!\r\n");
//									//RTC_ITConfig(RTC_IT_SEC, DISABLE);	//关闭秒中断
//									printf("Will Standby!\r\n");
//									Sys_Enter_Standby();
//									//后面的代码执行不到了
//									printf("Cann't reach here!\r\n");
//							}
//				}
//	}// end of while (1)
//}








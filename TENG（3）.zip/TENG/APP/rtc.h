#ifndef __RTC_H
#define __RTC_H	    

#include "sys.h"
#include "usb_hid.h"
//RTC实时时钟 驱动代码

///////////  后备寄存器功能定义 ///////////////////////////////////
#define BKP_VALID					0x5AA5				// 后备存储区是否实效比较值

#define BKP_R_VALID					BKP_DR1				// 后备存储区是否失效
#define BKP_R_ADXL_SET				BKP_DR2				// ADXL设置初始值
#define BKP_R_ACC_NUM				BKP_DR3				// 3D数据文件计数
#define BKP_R_ACC_DEL_NUM			BKP_DR4				// 3D数据删除文件计数
#define BKP_R_GPS_NUM				BKP_DR5				// GPS数据文件计数
#define BKP_R_GPS_DEL_NUM			BKP_DR6				// GPS数据删除文件计数
#define BKP_R_GPS_UPDATE_COUNT		BKP_DR7				// GPS取值间隔
#define BKP_R_TEHU_NUM				BKP_DR8				// 温湿度数据文件计数
#define BKP_R_TEHU_DEL_NUM			BKP_DR9				// 温湿度数据删除文件计数
#define BKP_R_TEHU_UPDATE_COUNT		BKP_DR10			// 温湿度取值间隔

extern u8 const mon_table[12];	//月份日期数据表 

void Disp_Time(u8 x,u8 y,u8 size);//在制定位置开始显示时间
void Disp_Week(u8 x,u8 y,u8 size,u8 lang);//在指定位置显示星期
u8 RTC_Init(void);        //初始化RTC,返回0,失败;1,成功;
u8 Is_Leap_Year(u16 year);//平年,闰年判断
u8 RTC_Get(void);         //更新时间   
u8 RTC_Get_Week(u16 year,u8 month,u8 day);
u8 RTC_Set(u16 syear,u8 smon,u8 sday,u8 hour,u8 min,u8 sec);//设置时间			
u8 RTC_Alarm_Set(u16 syear,u8 smon,u8 sday,u8 hour,u8 min,u8 sec);


#endif



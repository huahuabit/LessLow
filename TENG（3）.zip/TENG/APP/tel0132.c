#include "stm32f10x.h"                  // Device header
#include "usart1.h"
#include "tel0132.h"
#include "adc.h"
uint16_t adc_0132;

void tel0132(void)
{
		ADC_SoftwareStartConvCmd(ADC2, ENABLE);
    while(!ADC_GetFlagStatus(ADC2, ADC_FLAG_EOC));
		adc_0132 = ADC_Read_PC1();

//	// 将采集结果通过串口输出
//	printf("SEN0359: %d\n\r",adc_0359);
}




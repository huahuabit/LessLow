#include "bme680.h"
#include "stm32f10x.h"
#include "bme680.h"
#include "usart1.h"
#include "bme680_internal.h"
#define BME680_ADDRESS      0x76        //I2C从机地址，SDO接地时为0x76

/**
  * 函    数：等待事件
  * 参    数：同I2C_CheckEvent
  * 返 回 值：无
  */
void BME680_WaitEvent(I2C_TypeDef* I2Cx, uint32_t I2C_EVENT)
{
    uint32_t Timeout;
    Timeout = 10000;                                    //给定超时计数时间
    while (I2C_CheckEvent(I2Cx, I2C_EVENT) != SUCCESS)  //循环等待指定事件
    {
        Timeout --;                                     //等待时，计数值自减
        if (Timeout == 0)                               //自减到0后，等待超时
        {
            printf("timeout\n\r");
            /*超时的错误处理代码，可以添加到此处*/
            break;                                      //跳出等待，不等了
        }
    }
}

/**
  * 函    数：BME680写寄存器
  * 参    数：RegAddress 寄存器地址
  * 参    数：Data 要写入寄存器的数据，范围：0x00~0xFF
  * 返 回 值：无
  */
void BME680_WriteReg(uint8_t RegAddress, uint8_t Data)
{
    I2C_GenerateSTART(I2C2, ENABLE);                                        //硬件I2C生成起始条件
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT);                   //等待EV5
    
    I2C_Send7bitAddress(I2C2, BME680_ADDRESS, I2C_Direction_Transmitter);   //硬件I2C发送从机地址，方向为发送
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED);    //等待EV6
    
    I2C_SendData(I2C2, RegAddress);                                         //硬件I2C发送寄存器地址
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTING);            //等待EV8
    
    I2C_SendData(I2C2, Data);                                               //硬件I2C发送数据
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED);             //等待EV8_2
    
    I2C_GenerateSTOP(I2C2, ENABLE);                                         //硬件I2C生成终止条件
}

/**
  * 函    数：BME680读寄存器
  * 参    数：RegAddress 寄存器地址
  * 返 回 值：读取寄存器的数据，范围：0x00~0xFF
  */
uint8_t BME680_ReadReg(uint8_t RegAddress)
{
    uint8_t Data;
    
    I2C_GenerateSTART(I2C2, ENABLE);                                        //硬件I2C生成起始条件
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT);                   //等待EV5
    
    I2C_Send7bitAddress(I2C2, BME680_ADDRESS, I2C_Direction_Transmitter);   //硬件I2C发送从机地址，方向为发送
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED);    //等待EV6
    
    I2C_SendData(I2C2, RegAddress);                                         //硬件I2C发送寄存器地址
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED);             //等待EV8_2
    
    I2C_GenerateSTART(I2C2, ENABLE);                                        //硬件I2C生成重复起始条件
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT);                   //等待EV5
    
    I2C_Send7bitAddress(I2C2, BME680_ADDRESS, I2C_Direction_Receiver);      //硬件I2C发送从机地址，方向为接收
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED);       //等待EV6
    
    I2C_AcknowledgeConfig(I2C2, DISABLE);                                   //在接收最后一个字节之前提前将应答失能
    I2C_GenerateSTOP(I2C2, ENABLE);                                         //在接收最后一个字节之前提前申请停止条件
    
    BME680_WaitEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED);                //等待EV7
    Data = I2C_ReceiveData(I2C2);                                           //接收数据寄存器
    
    I2C_AcknowledgeConfig(I2C2, ENABLE);                                    //将应答恢复为使能，为了不影响后续可能产生的读取多字节操作
    printf("%c",Data);
    return Data;
}

/**
  * 函    数：BME680初始化
  * 参    数：无
  * 返 回 值：无
  */
void BME680_Init(void)
{
    /*开启时钟*/
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);       //开启I2C2的时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);      //开启GPIOB的时钟
    
    /*GPIO初始化*/
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);                     //将PB10和PB11引脚初始化为复用开漏输出
    
    /*I2C初始化*/
    I2C_InitTypeDef I2C_InitStructure;                         //定义结构体变量
    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;                 //模式，选择为I2C模式
    I2C_InitStructure.I2C_ClockSpeed = 50000;                  //时钟速度，选择为50KHz
    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;         //时钟占空比，选择Tlow/Thigh = 2
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;                //应答，选择使能
    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit; //应答地址，选择7位
    I2C_InitStructure.I2C_OwnAddress1 = 0x00;                  //自身地址，从机模式下才有效
    I2C_Init(I2C2, &I2C_InitStructure);                        //将结构体变量交给I2C_Init，配置I2C2
    
    /*I2C使能*/
    I2C_Cmd(I2C2, ENABLE);                                     //使能I2C2，开始运行
    
    /*BME680寄存器初始化*/
    // 配置湿度采样率
    BME680_WriteReg(0x72, 0x01);  // CTRL_HUM, oversampling x1
    // 配置温度和压力采样率
    BME680_WriteReg(0x74, 0x25);  // CTRL_MEAS, temp oversampling x2, press oversampling x16
    // 配置IIR滤波器
    BME680_WriteReg(0x75, 0x00);  // CONFIG, IIR filter off
    // 配置气体传感器
    BME680_WriteReg(0x71, 0x10);  // CTRL_GAS_1, run gas and use heater profile 0
    // 配置加热器参数
    BME680_WriteReg(0x5A, 0x59);  // res_heat_0, heater resistance for 300°C
    BME680_WriteReg(0x64, 0x59);  // gas_wait_0, 100ms heating duration
}

/**
  * 函    数：BME680获取ID号
  * 参    数：无
  * 返 回 值：BME680的ID号
  */
uint8_t BME680_GetID(void)
{
    return BME680_ReadReg(0xD0);     //读取ID寄存器(0xD0)，BME680的ID应该是0x61
}

// 其他功能函数需要根据实际需求实现






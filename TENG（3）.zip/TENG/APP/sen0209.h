#ifndef __SEN0209_H
#define __SEN0209_H

void sen0209_init(void);
void sen0209(void);


#endif

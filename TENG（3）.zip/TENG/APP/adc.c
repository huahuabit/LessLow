#include "stm32f10x.h"

uint16_t adc_0209;
uint16_t adc_0132;

void adc_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStructure;

    // 1. 使能时钟（GPIOC和ADC1）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_ADC1, ENABLE);
    
    // 2. 配置ADC时钟（PCLK2的6分频，12MHz/6=2MHz）
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);  // 确保ADC时钟不超过14MHz

    // 3. 配置PC0和PC1为模拟输入
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    // 4. ADC参数配置
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;      // 独立模式
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;           // 多通道扫描模式
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;    // 单次转换
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None; // 软件触发
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right; // 数据右对齐
    ADC_InitStructure.ADC_NbrOfChannel = 2;                // 2个转换通道
    ADC_Init(ADC1, &ADC_InitStructure);

    // 5. 配置ADC1通道10和11（PC0对应ADC1_IN10，PC1对应ADC1_IN11）
    // 通道10，采样顺序1，采样时间55.5周期
    ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1, ADC_SampleTime_55Cycles5);
    // 通道11，采样顺序2，采样时间55.5周期
    ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 2, ADC_SampleTime_55Cycles5);

    // 6. 使能ADC
    ADC_Cmd(ADC1, ENABLE);

    // 7. ADC校准（必须步骤）
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));  // 等待复位完成
    
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));       // 等待校准完成
}

void ADC_Start_Conversion(void)
{
    // 启动ADC转换
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}

uint16_t ADC_Read_PC0(void) // sen0209
{
		ADC_Start_Conversion();
    // 等待转换完成
    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
    
    // 返回第一个转换结果（通道10，PC0）
    return ADC_GetConversionValue(ADC1);
}

uint16_t ADC_Read_PC1(void) // tel0132
{
		ADC_Start_Conversion();
    // 等待第二个通道转换完成
    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
    
    // 再次读取获取第二个通道结果（通道11，PC1）
    return ADC_GetConversionValue(ADC1);
}

void sen0209(void)
{
	// ADC数据采集
	adc_0209 = ADC_Read_PC0();

//	// 将采集结果通过串口输出
//	printf("SEN0209: %d\n\r", adc_0209);

}

void tel0132(void)
{
		
		adc_0132 = ADC_Read_PC1();

//	// 将采集结果通过串口输出
//	printf("SEN0359: %d\n\r",adc_0359);
}





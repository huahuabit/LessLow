#include "Gps.h"
#include "usart3.h"
#include "Delay.h"
#include <stdio.h>
#include "stdlib.h"

GPS_Data Save_Data;
char gpsRxBuffer[GPS_RX_BUFFER_LENGTH];
unsigned int gpsRxLength = 0;
const unsigned int gpsRxBufferLength = GPS_RX_BUFFER_LENGTH;

void GPS_Init(void)
{
    memset(gpsRxBuffer, 0, GPS_RX_BUFFER_LENGTH);
    gpsRxLength = 0;
    
    Save_Data.GetData_Flag = false;
    Save_Data.ParseData_Flag = false;
    Save_Data.Usefull_Flag = false;
}

void RST_GpsRxBuffer(void)
{
    memset(gpsRxBuffer, 0, GPS_RX_BUFFER_LENGTH);
    gpsRxLength = 0;
}

void Read_Gps(void)
{
    char *GPS_DATAHead;
    char *GPS_DATATail;
    
    if ((GPS_DATAHead = strstr(gpsRxBuffer, "$GPRMC,")) != NULL || 
        (GPS_DATAHead = strstr(gpsRxBuffer, "$GNRMC,")) != NULL)
    {
        if (((GPS_DATATail = strstr(GPS_DATAHead, "\r\n")) != NULL) && (GPS_DATATail > GPS_DATAHead))
        {
            memcpy(Save_Data.GPS_DATA, GPS_DATAHead, GPS_DATATail - GPS_DATAHead);
            Save_Data.GetData_Flag = true;
            RST_GpsRxBuffer();
        }
    }
}

void parse_GpsDATA(void)
{
    char *subString;
    char *subStringNext;
    char usefulBuffer[2];
    
    if (Save_Data.GetData_Flag)
    {
        Save_Data.GetData_Flag = false;
        
        subString = Save_Data.GPS_DATA;
        for (int i = 0; i <= 6; i++)
        {
            if (i == 0)
            {
                if ((subString = strstr(subString, ",")) == NULL)
                    return; // 解析错误
            }
            else
            {
                subString++;
                if ((subStringNext = strstr(subString, ",")) != NULL)
                {
                    switch(i)
                    {
                        case 1: // 获取UTC时间
                            memcpy(Save_Data.UTCTime, subString, subStringNext - subString);
                            Save_Data.UTCTime[subStringNext - subString] = '\0';
                            break;
                        case 2: // 获取定位状态
                            memcpy(usefulBuffer, subString, subStringNext - subString);
                            usefulBuffer[subStringNext - subString] = '\0';
                            break;
                        case 3: // 获取纬度信息
                            memcpy(Save_Data.latitude, subString, subStringNext - subString);
                            Save_Data.latitude[subStringNext - subString] = '\0';
                            break;
                        case 4: // 获取N/S
                            memcpy(Save_Data.N_S, subString, subStringNext - subString);
                            Save_Data.N_S[subStringNext - subString] = '\0';
                            break;
                        case 5: // 获取经度信息
                            memcpy(Save_Data.longitude, subString, subStringNext - subString);
                            Save_Data.longitude[subStringNext - subString] = '\0';
                            break;
                        case 6: // 获取E/W
                            memcpy(Save_Data.E_W, subString, subStringNext - subString);
                            Save_Data.E_W[subStringNext - subString] = '\0';
                            break;
                        default:
                            break;
                    }
                    subString = subStringNext;
                }
                else
                {
                    return; // 解析错误
                }
            }
        }
        
        Save_Data.ParseData_Flag = true;
        if(usefulBuffer[0] == 'A')
            Save_Data.Usefull_Flag = true;
        else if(usefulBuffer[0] == 'V')
            Save_Data.Usefull_Flag = false;
    }
}

void print_GpsDATA(void)
{
    if (Save_Data.ParseData_Flag)
    {
        Save_Data.ParseData_Flag = false;
        
        printf("UTC Time: %s\r\n", Save_Data.UTCTime);
        
        if(Save_Data.Usefull_Flag)
        {
            printf("Latitude: %s %s\r\n", Save_Data.latitude, Save_Data.N_S);
            printf("Longitude: %s %s\r\n", Save_Data.longitude, Save_Data.E_W);
            
            // 转换为十进制度格式
						
            float lat_deg = atof(Save_Data.latitude);
            float lat_min = lat_deg - (int)(lat_deg / 100) * 100;
            float latitude = (int)(lat_deg / 100) + lat_min / 60;
            
            float lon_deg = atof(Save_Data.longitude);
            float lon_min = lon_deg - (int)(lon_deg / 100) * 100;
            float longitude = (int)(lon_deg / 100) + lon_min / 60;
            
            printf("Converted Latitude: %.6f %s\r\n", latitude, Save_Data.N_S);
            printf("Converted Longitude: %.6f %s\r\n", longitude, Save_Data.E_W);
        }
        else
        {
            printf("GPS DATA is not useful!! (No satellite fix - move to open area)\r\n");
        }
    }
    else
    {
        printf("UTC Time: (No GPS data received)\r\n");
        printf("GPS DATA is not useful!!\r\n");
    }
}




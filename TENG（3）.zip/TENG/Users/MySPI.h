#ifndef __MYSPI_H
#define __MYSPI_H
#include "stm32f10x.h"                  // Device header

void BME680_SPI_W_SS(uint8_t BitValue);
void BME680_SPI_Init(void);
void BME680_SPI_Start(void);
void BME680_SPI_Stop(void);
uint8_t BME680_SPI_SwapByte(uint8_t ByteSend);
s8 BME680_SPI_bus_read_user(u8 dev_id, u8 reg_addr, u8 *reg_data, u32 len);
s8 BME680_SPI_bus_write_user(u8 dev_id, u8 reg_addr, u8 *reg_data, u8 len);
s8 BME680_SPI_read_user(u8 dev_id, u8 reg_addr, u8 *reg_data, u8 len);

void Bme680_Init(void); //use
void Bme_Data(void);

#endif


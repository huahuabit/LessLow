#include "stm32f10x.h"                  // Device header
#include "Gps.h"
#include "usart3.h"	 

void Usart3Init(unsigned int uiBaud)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    // 1. 使能时钟（USART3在APB1总线，GPIOB用于USART3）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);       // GPIOB时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);     // USART3时钟
    
    // 2. 配置GPIO
    // USART3_TX -> PB10 (复用推挽输出)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);    

    // USART3_RX -> PB11 (浮空输入)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
      
    // 3. 配置NVIC中断
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;          // USART3中断通道
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;   // 抢占优先级3
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;          // 子优先级3
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;             // 使能中断
    NVIC_Init(&NVIC_InitStructure);    
    
    // 4. 配置USART参数
    USART_InitStructure.USART_BaudRate = uiBaud;                // 波特率
    USART_InitStructure.USART_WordLength = USART_WordLength_8b; // 8位数据
    USART_InitStructure.USART_StopBits = USART_StopBits_1;      // 1位停止位
    USART_InitStructure.USART_Parity = USART_Parity_No;         // 无校验
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // 无硬件流控
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx; // 收发模式
    USART_Init(USART3, &USART_InitStructure); 
    
    // 5. 配置中断
    USART_ITConfig(USART3, USART_IT_TXE, DISABLE);              // 禁用发送中断
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);              // 使能接收中断
    USART_ClearFlag(USART3, USART_FLAG_TC);                     // 清除传输完成标志
    USART_Cmd(USART3, ENABLE);                                  // 使能USART3
    
    // 6. 可选的二次NVIC配置（如果需要不同优先级）
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
		
}
void USART3_IRQHandler(void)
{
    char RxData;
    
    // 检查接收中断标志位
    if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
    {
        // 读取接收到的数据
        RxData = USART_ReceiveData(USART3);
//        
//        // 将数据存入缓冲区
//        if (gpsRxLength < gpsRxBufferLength - 1)
//        {
//            gpsRxBuffer[gpsRxLength++] = RxData;
//						//printf("%c",RxData);
//        }
//        else
//        { 
//						
//						RST_GpsRxBuffer(); // 缓冲区满，重置
//        }
//        
//        // 清除接收中断挂起位
        USART_ClearITPendingBit(USART3, USART_IT_RXNE);
    }
}






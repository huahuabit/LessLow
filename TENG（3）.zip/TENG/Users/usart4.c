#include "usart4.h"
#include "stm32f10x.h"                  // Device header
#include "Gps.h"

extern char gpsRxBuffer[600];
extern unsigned int gpsRxLength; 
extern const unsigned int gpsRxBufferLength; 

/**
 * @brief       UART4初始化函数
 * @param       无
 * @retval      无
 */
void uart4_Init()  
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure; 
    
    // UART4的时钟在APB1总线上
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // UART4的GPIO在PC10(TX), PC11(RX)
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
    
    // UART4 TX (PC10) 配置为复用推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);    
    
    // UART4 RX (PC11) 配置为浮空输入
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
     
    USART_InitStructure.USART_BaudRate = 9600;               // 波特率
    USART_InitStructure.USART_WordLength = USART_WordLength_8b; // 字长
    USART_InitStructure.USART_StopBits = USART_StopBits_1;    // 停止位
    USART_InitStructure.USART_Parity = USART_Parity_No;       // 校验位
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // 硬件流控
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx; // 收发模式
    USART_Init(UART4, &USART_InitStructure); 
    
    USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);             // 开启接收中断
    USART_Cmd(UART4, ENABLE);                                 // 使能UART4
    
    NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;          // 中断通道
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; // 抢占优先级
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;        // 响应优先级
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;           // 使能通道
    NVIC_Init(&NVIC_InitStructure);
}

/**
 * @brief       UART4接收中断服务函数 
 * @param       无
 * @retval      无
 */
void UART4_IRQHandler(void)
{
    uint8_t RxData;
    if (USART_GetITStatus(UART4, USART_IT_RXNE) == SET)
    {
        RxData = USART_ReceiveData(UART4);    /*读取接收到的数据*/
			
        // 将数据存入缓冲区
        if (gpsRxLength < gpsRxBufferLength - 1)
        {
            gpsRxBuffer[gpsRxLength++] = RxData;
						//printf("%c",RxData);
        }
        else
        { 
						
						RST_GpsRxBuffer(); // 缓冲区满，重置
        }
        
        // 清除接收中断挂起位
        USART_ClearITPendingBit(UART4, USART_IT_RXNE);
    }
}


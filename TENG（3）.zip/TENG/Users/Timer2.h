//#ifndef __TIMER2_H
//#define __TIMER2_H
//#include "stm32f10x.h"                  // Device header


//extern volatile uint8_t Progress;  // 声明全局变量


//void TIM2_Init(void);
//void TIM2_IRQHandler(void);


//#endif


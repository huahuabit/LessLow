#ifndef __TIMER1_H
#define __TIMER1_H

void Timer1_Init(void);
void TIM1_UP_IRQHandler(void);


#endif


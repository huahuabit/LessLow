#ifndef __USART2_H
#define __USART2_H

#include "stm32f10x.h"   

void usart2_Init(uint32_t bound);
void USART2_IRQHandler(void);
void USART2_SendData(uint8_t *data, uint16_t length);
void Serial2_SendArray(uint8_t *Array, uint16_t Length);

#endif

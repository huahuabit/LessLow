#ifndef __USART5_H
#define __USART5_H

#include <stdint.h>

// ȫ�ֱ�������
extern volatile uint8_t Cx, Cy, Cz, Cw;



void Serial5_Init(void);
void Serial5_SendByte(uint8_t Byte);
void Serial5_SendArray(uint8_t *Array, uint16_t Length);
void Serial5_SendString(char *String);
//static uint32_t Serial_Pow(uint32_t X, uint32_t Y);
void Serial5_SendNumber(uint32_t Number, uint8_t Length);
//int fputc(int ch, FILE *f);
void Serial5_Printf(char *format, ...);




#endif

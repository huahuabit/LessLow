#include "stm32f10x.h"                  // Device header

// 微秒级延时函数
void TIM7_Init(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
    
    TIM_TimeBaseInitStructure.TIM_Period = 50000-1;     // 自动重装载值
    TIM_TimeBaseInitStructure.TIM_Prescaler = 72-1;     // 定时器分频

    TIM_TimeBaseInit(TIM7, &TIM_TimeBaseInitStructure); // 初始化TIM7
}

// 微秒级延时
void Delay_us(uint32_t xus)
{
    TIM_Cmd(TIM7, ENABLE);    // 启动定时器
    while(TIM7->CNT < xus);
    TIM7->CNT = 0;
    TIM_Cmd(TIM7, DISABLE);   // 关闭定时器
}

// 毫秒级延时
void Delay_ms(uint32_t xms)
{
    int i;
    for(i=0; i<xms; i++)
    {
        Delay_us(1000);
    }
}


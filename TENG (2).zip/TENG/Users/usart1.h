#ifndef __UART1_H
#define __UART1_H
#include <stdio.h>

void Usart1Init(unsigned int uiBaud);
int fputc(int ch, FILE *file);
void CopeCmdData(unsigned char ucData);
void USART1_IRQHandler(void);

#endif

#include "stm32f10x.h"                  // Device header
#include "Timer1.h"
#include "Launch.h"
#include "stdbool.h"
#include "usart1.h"
#include "Timer2.h"
#include "sen0209.h"
#include "tel0132.h"

extern uint16_t adc_0209;
extern uint16_t adc_0132;

void Timer1_Init(void)
{
	 // 1. 使能TIM1时钟（APB2总线）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

    // 2. 配置内部时钟源
    TIM_InternalClockConfig(TIM1);

    // 3. 时基单元配置（72MHz系统时钟下，1秒周期）
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;          // 时钟分频（无分频）
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;      // 向上计数
    TIM_TimeBaseInitStruct.TIM_Period = 9999;                         // 自动重装值（0~9999，共10000次计数）
    TIM_TimeBaseInitStruct.TIM_Prescaler = 7199;                      // 预分频（7200分频，72MHz/7200=10kHz）
    TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;                 // 重复计数（高级定时器专用）
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseInitStruct);                  // 初始化时基

    // 4. 清除初始更新标志
    TIM_ClearFlag(TIM1, TIM_FLAG_Update);

    // 5. 使能更新中断（注意高级定时器需要额外使能）
    TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
    TIM_CtrlPWMOutputs(TIM1, ENABLE);  // 高级定时器必须开启主输出

    // 6. NVIC配置
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = TIM1_UP_IRQn;                  // TIM1更新中断通道
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;           // 较高优先级
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStruct);

    // 7. 启动定时器（高级定时器需要额外操作）
    TIM_Cmd(TIM1, ENABLE);
		
}

void TIM1_UP_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
    {
				sen0209();
				tel0132();
        output();  // 执行目标函数
        TIM_ClearITPendingBit(TIM1, TIM_IT_Update);  // 清除中断标志
        // 高级定时器必须清除BDTR寄存器的MOE位相关标志（如果使用PWM输出）
        TIM_ClearFlag(TIM1, TIM_FLAG_Trigger);
    }
}



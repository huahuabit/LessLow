#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "usart5.h"
volatile uint8_t Cx, Cy, Cz, Cw;
int D;

void usart5_Init(void)  // ����
{
    // ����UART5��GPIOC/Dʱ��
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);
    
    // UART5_TX -> PC12
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    
    // UART5_RX -> PD2
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  // UART5ʹ�ø�������
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    
    USART_InitTypeDef USART_InitStructure;
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_Init(UART5, &USART_InitStructure);
    
    USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStructure);
    
    USART_Cmd(UART5, ENABLE);
}

uint8_t RxData;

void UART5_IRQHandler(void)             
{

    if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)   // �����ж�  
    {
        USART_ClearITPendingBit(UART5, USART_IT_RXNE);     // ����жϱ�־
        RxData = USART_ReceiveData(UART5);
       
			
			 USART_ClearITPendingBit(UART5, USART_IT_RXNE);
		}
}

/********************** ���ڷ��͹��� **********************/

/**
  * @brief  ���͵����ֽ�
  * @param  Byte: Ҫ���͵��ֽ�
  */
void Serial5_SendByte(uint8_t Byte)
{
    USART_SendData(UART5, Byte);
    while(USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET);
}

/**
  * @brief  ��������
  * @param  Array: �����׵�ַ
  * @param  Length: ���鳤��
  */
void Serial5_SendArray(uint8_t *Array, uint16_t Length)
{
    for(uint16_t i = 0; i < Length; i++)
    {
        Serial5_SendByte(Array[i]);
    }
}

/**
  * @brief  �����ַ���
  * @param  String: �ַ����׵�ַ
  */
void Serial5_SendString(char *String)
{
    for(uint8_t i = 0; String[i] != '\0'; i++)
    {
        Serial5_SendByte(String[i]);
    }
}

/**
  * @brief  �η����㣨�ڲ�ʹ�ã�
  */
static uint32_t Serial_Pow(uint32_t X, uint32_t Y)
{
    uint32_t Result = 1;
    while(Y--)
    {
        Result *= X;
    }
    return Result;
}

/**
  * @brief  ��������
  * @param  Number: Ҫ���͵����֣�0-4294967295��
  * @param  Length: ���ֳ��ȣ�0-10��
  */
void Serial5_SendNumber(uint32_t Number, uint8_t Length)
{
    for(uint8_t i = 0; i < Length; i++)
    {
        Serial5_SendByte(Number / Serial_Pow(10, Length - i - 1) % 10 + '0');
    }
}

///**
//  * @brief  printf�ض���
//  */
//int fputc(int ch, FILE *f)
//{
//    Serial5_SendByte(ch);
//    return ch;
//}

/**
  * @brief  �Զ����ʽ�����
  */
void Serial5_Printf(char *format, ...)
{
    char String[100];
    va_list arg;
    va_start(arg, format);
    vsprintf(String, format, arg);
    va_end(arg);
    Serial5_SendString(String);
}


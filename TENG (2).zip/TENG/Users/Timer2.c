//#include "stm32f10x.h"                  // Device header
//#include "sen0209.h"
//#include "tel0132.h"
//#include "Timer2.h"
//#include "stdbool.h"
//#include "Delay.h"
//#include "usart1.h"

//void TIM2_Init(void)
//{
//    // 1. 使能TIM2时钟（APB1总线，注意与TIM1不同）
//    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

//    // 2. 配置内部时钟源
//    TIM_InternalClockConfig(TIM2);

//    // 3. 时基单元配置（72MHz系统时钟下，1秒周期）
//    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
//    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;        // 时钟分频（无分频）
//    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;    // 向上计数
//    TIM_TimeBaseInitStruct.TIM_Period = 29999;                       // 自动重装值（0~9999）
//    TIM_TimeBaseInitStruct.TIM_Prescaler = 1799;                    // 预分频7200（72MHz/7200=10kHz）
//    TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;               // 通用定时器无效（保留0）
//    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct);

//    // 4. 清除初始更新标志
//    TIM_ClearFlag(TIM2, TIM_FLAG_Update);

//    // 5. 使能更新中断
//    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

//    // 6. NVIC配置（中断优先级）
//    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);                 // 优先级分组：2位抢占，2位子优先级
//    NVIC_InitTypeDef NVIC_InitStruct;
//    NVIC_InitStruct.NVIC_IRQChannel = TIM2_IRQn;                    // TIM2中断通道
//    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;          // 抢占优先级2
//    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;                 // 子优先级1
//    NVIC_Init(&NVIC_InitStruct);

//    // 7. 启动定时器
//    TIM_Cmd(TIM2, ENABLE);
//}

//// TIM2中断服务函数
//void TIM2_IRQHandler(void)
//{
//    if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
//    {
//			if(Progress == 0)
//			{
//				sen0209();
//				tel0132();
//				Progress = 1;
//				__WFI();
//			}
//      TIM_ClearITPendingBit(TIM2, TIM_IT_Update);  // 清除中断标志
//    }
//}





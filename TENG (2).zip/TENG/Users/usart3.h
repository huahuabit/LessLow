#ifndef __USART3_H
#define __USART3_H
#include "stm32f10x.h"                  // Device header


void Usart3Init(unsigned int uiBaud);
void USART3_IRQHandler(void);


#endif


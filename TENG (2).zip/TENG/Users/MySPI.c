#include "stm32f10x.h"                  // Device header
#include "bme680.h"
#include "MySPI.h"
#include "Delay.h"
#include "usart1.h"

/**
  * 函    数：SPI写SS引脚电平，SS仍由软件模拟
  * 参    数：BitValue 协议层传入的当前需要写入SS的电平，范围0~1
  * 返 回 值：无
  * 注意事项：此函数需要用户实现内容，当BitValue为0时，需要置SS为低电平，当BitValue为1时，需要置SS为高电平
  */
void BME680_SPI_W_SS(uint8_t BitValue)
{
    GPIO_WriteBit(GPIOA, GPIO_Pin_4, (BitAction)BitValue); // 根据BitValue设置SS引脚电平
}

/**
  * 函    数：SPI初始化
  * 参    数：无
  * 返 回 值：无
  */
void BME680_SPI_Init(void)
{
    /* 开启时钟 */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // 开启GPIOA的时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);  // 开启SPI1的时钟

    /* GPIO初始化 */
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;              // SS引脚
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);                // 将PA4初始化为推挽输出

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_7; // SCK和MOSI引脚
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);                // 将PA5和PA7初始化为复用推挽输出

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;              // MISO引脚
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);                // 将PA6初始化为上拉输入

    /* SPI初始化 */
    SPI_InitTypeDef SPI_InitStructure;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;         // 主模式
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex; // 全双工
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;     // 8位数据
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;    // 高位先行
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_128; // 128分频
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;            // CPOL = 0
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;          // CPHA = 1 (模式1)
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;             // 软件控制NSS
    SPI_InitStructure.SPI_CRCPolynomial = 7;              // CRC多项式
    SPI_Init(SPI1, &SPI_InitStructure);                   // 初始化SPI1

    /* SPI使能 */
    SPI_Cmd(SPI1, ENABLE);                                // 使能SPI1

    /* 设置默认电平 */
    BME680_SPI_W_SS(1);                                   // SS默认高电平
}

/**
  * 函    数：SPI起始
  * 参    数：无
  * 返 回 值：无
  */
void BME680_SPI_Start(void)
{
    BME680_SPI_W_SS(0);                                   // 拉低SS，开始时序
}

/**
  * 函    数：SPI终止
  * 参    数：无
  * 返 回 值：无
  */
void BME680_SPI_Stop(void)
{
    BME680_SPI_W_SS(1);                                   // 拉高SS，终止时序
}

/**
  * 函    数：SPI交换传输一个字节
  * 参    数：ByteSend 要发送的一个字节
  * 返 回 值：接收的一个字节
  */
uint8_t BME680_SPI_SwapByte(uint8_t ByteSend)
{
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) != SET); // 等待发送寄存器空
    SPI_I2S_SendData(SPI1, ByteSend);                     // 发送数据
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) != SET); // 等待接收寄存器非空
    return SPI_I2S_ReceiveData(SPI1);                     // 返回接收到的数据
}

/**
  * 函    数：BME680 SPI总线读取函数
  * 参    数：dev_id 设备ID（未使用）
  * 参    数：reg_addr 寄存器地址
  * 参    数：reg_data 读取的数据存储指针
  * 参    数：len 要读取的数据长度
  * 返 回 值：BME680通信结果
  */
s8 BME680_SPI_bus_read_user(u8 dev_id, u8 reg_addr, u8 *reg_data, u32 len)
{
    (void)dev_id; // 未使用，避免警告

    BME680_SPI_Start();                                   // 启动SPI通信
    BME680_SPI_SwapByte(reg_addr | 0x80);                 // 发送寄存器地址（读操作，最高位置1）
    for (uint16_t i = 0; i < len; i++) {
        reg_data[i] = BME680_SPI_SwapByte(0x00);          // 读取数据
    }
    BME680_SPI_Stop();                                    // 停止SPI通信
    return BME680_COMM_RES_OK;                            // 返回成功
}

/**
  * 函    数：BME680 SPI总线写入函数
  * 参    数：dev_id 设备ID（未使用）
  * 参    数：reg_addr 寄存器地址
  * 参    数：reg_data 要写入的数据指针
  * 参    数：len 要写入的数据长度
  * 返 回 值：BME680通信结果
  */
s8 BME680_SPI_bus_write_user(u8 dev_id, u8 reg_addr, u8 *reg_data, u8 len)
{
    (void)dev_id; // 未使用，避免警告

    BME680_SPI_Start();                                   // 启动SPI通信
    BME680_SPI_SwapByte(reg_addr & 0x7F);                 // 发送寄存器地址（写操作，最高位清零）
    for (uint16_t i = 0; i < len; i++) {
        BME680_SPI_SwapByte(reg_data[i]);                 // 写入数据
    }
    BME680_SPI_Stop();                                    // 停止SPI通信
    return BME680_COMM_RES_OK;                            // 返回成功
}


/**
  * 函    数：BME680 SPI总线读取函数
  * 参    数：dev_id 设备ID（未使用）
  * 参    数：reg_addr 寄存器地址
  * 参    数：reg_data 读取的数据存储指针
  * 参    数：len 要读取的数据长度
  * 返 回 值：BME680通信结果
  */
s8 BME680_SPI_read_user(u8 dev_id, u8 reg_addr, u8 *reg_data, u8 len)
{
    (void)dev_id; // 未使用，避免警告

    BME680_SPI_Start();                                   // 启动SPI通信
    BME680_SPI_SwapByte(reg_addr | 0x80);                 // 发送寄存器地址（读操作，最高位置1）
    for (uint16_t i = 0; i < len; i++) {
        reg_data[i] = BME680_SPI_SwapByte(0x00);          // 读取数据
    }
    BME680_SPI_Stop();                                    // 停止SPI通信
    return BME680_COMM_RES_OK;                            // 返回成功
}


/*!
* BME680_MAX_NO_OF_SENSOR = 2; 在bme680.h文件中定义
* 如果只需要通过SPI接口连接一个传感器，用户必须将BME680_MAX_NO_OF_SENSOR的值改为1
* 测试设置：假设BME680传感器0通过SPI接口连接，使用原生片选线
*/

/* BME680传感器结构体实例 */
struct bme680_t bme680_sensor_no[BME680_MAX_NO_OF_SENSOR];
/* BME680传感器补偿数据结构体实例 */
struct bme680_comp_field_data compensate_data_sensor[BME680_MAX_NO_OF_SENSOR][3];
/* BME680传感器未补偿数据结构体实例 */
struct bme680_uncomp_field_data uncompensated_data_of_sensor[BME680_MAX_NO_OF_SENSOR][3];
/* BME680传感器配置结构体实例 */
struct bme680_sens_conf set_conf_sensor[BME680_MAX_NO_OF_SENSOR];
/* BME680传感器加热器配置结构体实例 */
struct bme680_heater_conf set_heatr_conf_sensor[BME680_MAX_NO_OF_SENSOR];

void Bme680_Init(void)
{
		BME680_SPI_Init();
    //enum bme680_return_type com_rslt = BME680_COMM_RES_ERROR;
    
    /* 初始化BME680传感器结构体实例 */
    /* 传感器0通过SPI接口连接，使用原生片选线 */
    /* 用户定义的SPI总线读取函数 */
    bme680_sensor_no[0].bme680_bus_read = BME680_SPI_read_user;
    /* 用户定义的SPI总线写入函数 */
    bme680_sensor_no[0].bme680_bus_write = BME680_SPI_bus_write_user;
    /* 用户定义的SPI突发读取函数 */
    bme680_sensor_no[0].bme680_burst_read = BME680_SPI_bus_read_user;
    /* 用户定义的延时函数 */
    bme680_sensor_no[0].delay_msec = Delay_us;
    /* 指定通信接口 */
    bme680_sensor_no[0].interface = BME680_SPI_INTERFACE;
}
void Bme_Data(void)
{
		unsigned int i = 0;
		enum bme680_return_type com_rslt = BME680_COMM_RES_ERROR;
    /* 获取芯片ID和校准参数 */
    com_rslt = bme680_init(&bme680_sensor_no[0]);
		printf("BME680 Chip ID Verified: 0x%02X\n\r", bme680_sensor_no[i].chip_id);
		
	/* 传感器初始化 */
    for (i=0;i<BME680_MAX_NO_OF_SENSOR;i++) {
        /* 在执行传感器操作前检查设备ID */
       // if (BME680_CHIP_ID_1 == bme680_sensor_no[i].chip_id||BME680_CHIP_ID_2 == bme680_sensor_no[i].chip_id||BME680_CHIP_ID_3 == bme680_sensor_no[i].chip_id) 
				//	{
            /* 选择传感器配置参数 */
            set_conf_sensor[i].heatr_ctrl = BME680_HEATR_CTRL_ENABLE;  // 启用加热器控制
            set_conf_sensor[i].run_gas = BME680_RUN_GAS_ENABLE;        // 启用气体测量
            set_conf_sensor[i].nb_conv = 0x00;                         // 转换次数
            set_conf_sensor[i].osrs_hum = BME680_OSRS_1X;              // 湿度1倍过采样
            set_conf_sensor[i].osrs_pres = BME680_OSRS_1X;             // 压力1倍过采样
            set_conf_sensor[i].osrs_temp = BME680_OSRS_1X;             // 温度1倍过采样
            
            /* 激活传感器配置 */
            com_rslt += bme680_set_sensor_config(&set_conf_sensor[i],
            &bme680_sensor_no[i]);
            
            /* 选择加热器配置参数 */
            set_heatr_conf_sensor[i].heater_temp[0] = 300;             // 加热器温度300°C
            set_heatr_conf_sensor[i].heatr_dur_shared = 1;             // 共享加热持续时间
            set_heatr_conf_sensor[i].heatr_dur[0] = 137;               // 加热持续时间137ms
            set_heatr_conf_sensor[i].profile_cnt = 1;                  // 配置计数
            
            /* 激活加热器配置 */
            com_rslt += bme680_set_gas_heater_config(&set_heatr_conf_sensor[i],
            &bme680_sensor_no[i]);
            
            /* 设置电源模式为强制模式 */
            com_rslt += bme680_set_power_mode(BME680_FORCED_MODE,&bme680_sensor_no[i]);
            
            if (BME680_COMM_RES_OK == com_rslt) {
                /* 获取未补偿的温度+压力+气体+湿度数据 */
                bme680_get_uncomp_data(uncompensated_data_of_sensor[i], 1, BME680_ALL,&bme680_sensor_no[i]);
                
                /* 获取补偿后的温度+压力+气体+湿度数据 */
                bme680_compensate_data(uncompensated_data_of_sensor[i],compensate_data_sensor[i], 1,BME680_ALL, &bme680_sensor_no[i]);
                
                /* 显式将传感器设置为睡眠模式 */
                bme680_set_power_mode(BME680_SLEEP_MODE, &bme680_sensor_no[i]);
                
                /* 调用用户定义的延时函数(持续时间毫秒) */
                Delay_ms(100);
            }
//        }
//				else
//					printf("ID is wrong\r\n");
//   }
	}
}









#include "stm32f10x.h"                  // Device header
#include "Launch.h"
#include "Gps.h"
#include "usart1.h"
#include "Delay.h"
#include "sen0209.h"
#include "tel0132.h"
//#include "PWR.h"  有关低功耗不能使用
//#include "rtc.h"
/*代码中PWR和rtc有关部分应该不能使用，rtc中断服务我不能正常打开*/
int main()
{
	All_Init();
	while(1)
	{
		
	}
}






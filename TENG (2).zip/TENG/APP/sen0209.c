#include "stm32f10x.h"                  // Device header
#include "sen0209.h"
#include "usart1.h"

uint16_t adc_0209;

void sen0209_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	ADC_InitTypeDef ADC_InitStructure;

	// 1. 使能时钟（GPIOA和ADC1）
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_ADC1, ENABLE);
	
	// 2. 配置ADC时钟（PCLK2的6分频，12MHz/6=2MHz）
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);  // 确保ADC时钟不超过14MHz

	// 3. 配置PA1为模拟输入（ADC1_IN1）
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;  // 修改为PA1
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// 4. ADC参数配置
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;      // 独立模式
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;           // 单通道模式
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;     // 单次转换
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None; // 软件触发
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;  // 数据右对齐
	ADC_InitStructure.ADC_NbrOfChannel = 1;                 // 1个转换通道
	ADC_Init(ADC1, &ADC_InitStructure);

	// 5. 配置ADC1通道1（PA1对应ADC1_IN1）
	ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_55Cycles5);  // 修改为Channel_1

	// 6. 使能ADC
	ADC_Cmd(ADC1, ENABLE);

	// 7. ADC校准（必须步骤）
	ADC_ResetCalibration(ADC1);
	while(ADC_GetResetCalibrationStatus(ADC1));  // 等待复位完成
	
	ADC_StartCalibration(ADC1);
	while(ADC_GetCalibrationStatus(ADC1));       // 等待校准完成
}


void sen0209(void)
{
	// ADC数据采集
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);
	while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
	adc_0209 = ADC_GetConversionValue(ADC1);

//	// 将采集结果通过串口输出
//	printf("SEN0209: %d\n\r", adc_0209);

}




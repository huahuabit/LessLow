#ifndef __LAUNCH_H
#define __LAUNCH_H

#include "stdbool.h"
#include "stm32f10x.h"                  // Device header

void SystemClock_Config(void);
void output(void);
void All_Init(void);
void Sys_Enter_Standby(void);
void IdleHandle(void);

#endif


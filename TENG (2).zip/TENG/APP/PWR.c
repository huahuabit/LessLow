#include "PWR.h"
#include "stm32f10x.h"                  // Device header
#include "Launch.h"
#include "usart1.h"

uint16_t mode_sign = SportMode;   //初始状态
volatile uint8_t lowpower_mode = 0;  // 定义全局变量

void WKUP_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // 1. 使能GPIOA和PWR时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
    
    // 2. 配置PA0为下拉输入（因为按键接3.3V）
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; // 下拉输入
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 3. 使能WKUP引脚唤醒功能
    PWR_WakeUpPinCmd(ENABLE);
}
// 关闭所有可能引起唤醒的外设
void Disable_Wakeup_Sources(void) {
    // 1. 禁用所有中断（除了EXTI0）
    NVIC->ICER[0] = 0xFFFFFFFF; // 禁用所有32个中断
    NVIC_EnableIRQ(EXTI0_IRQn); // 重新启用EXTI0中断
    
    // 2. 关闭不必要的外设时钟
    RCC->APB2ENR = 0;//RCC_APB2PeriphClockCmd(RCC_APB2Periph_ALL, DISABLE);
    RCC->APB1ENR = 0;//RCC_APB1PeriphClockCmd(RCC_APB1Periph_ALL, DISABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
    
    // 3. 配置未使用的GPIO为模拟输入（降低功耗）
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_All;
    GPIO_Init(GPIOA, &GPIO_InitStruct);
    GPIO_Init(GPIOB, &GPIO_InitStruct);
    GPIO_Init(GPIOC, &GPIO_InitStruct);
    
    // 4. 特别关闭串口等可能产生中断的外设
		USART_Cmd(USART1, DISABLE);
    USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
    USART_Cmd(USART2, DISABLE);
    USART_ITConfig(USART2, USART_IT_RXNE, DISABLE);
    USART_Cmd(UART4, DISABLE);
    USART_ITConfig(UART4, USART_IT_RXNE, DISABLE);
}

void Enter_SleepMode(void)
{
	// 配置PA0为外部中断
    GPIO_InitTypeDef GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    
    // PA0配置为上拉输入
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 配置EXTI线0
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling; // 上升沿和下降沿
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    // 配置NVIC
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
		
    printf("Enter_SleepMode\r\n");
    // 进入睡眠模式
    __WFI(); // 等待中断唤醒
}

void Enter_StopMode(void)
{
	printf("Enter_StopMode\r\n");
	// 配置PA0为外部中断
    GPIO_InitTypeDef GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    
    // PA0配置为上拉输入
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 配置EXTI线0
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling; // 上升沿和下降沿
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    
    // 配置NVIC
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
	// 进入停止模式前可以选择降低电压调节器功耗
    PWR_EnterSTOPMode(PWR_Regulator_LowPower, PWR_STOPEntry_WFI);
    
    // 唤醒后需要重新配置系统时钟
    SystemClock_Config(); // 重新初始化系统时钟
		printf("Enter_StopMode2\r\n");
}
void Enter_StandbyMode(void) 
{
	printf("Enter_StandbyMode1\r\n");
	// 1. 清除所有唤醒标志
    PWR_ClearFlag(PWR_FLAG_WU);
	
	  // 2. 禁用所有可能产生唤醒的外设
    Disable_Wakeup_Sources();
    
    // 3. 进入待机模式
    PWR_EnterSTANDBYMode();
	
	  // 4. 唤醒后会从复位开始执行
	printf("Enter_StandbyMode2\r\n");

}

void EXTI0_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line0) != RESET)
    {
        EXTI_ClearITPendingBit(EXTI_Line0);
        // 唤醒后的处理
				//All_Init();
				//output();
			printf("EXTI0 Triggered!\r\n");
    }
}


void Mode_Choice(uint16_t mode_sign)
{
	switch(mode_sign)
			{
				case (SportMode):
				{
					All_Init();
					break;
				}
				case (SleepMode):
				{
					Enter_SleepMode();
					break;
				}
				case (StopMode):
				{
					Enter_StopMode();
					break;
				}
				case(StandbyMode):
				{
					Enter_StandbyMode();
					break;
				}
				default:
					break;
			}
}
void RTC_Progress(uint16_t lowpower_mode)
{
	switch(lowpower_mode)
	{
		// 选择进入哪种低功耗模式
		case (0) :
		{
			mode_sign = SportMode;
			//lowpower_mode++;
			break;
		}
		case (5) :
		{
			mode_sign = SleepMode;
			//lowpower_mode++;
			break;
		}
		case (10) :
		{
			mode_sign = StopMode;
			//lowpower_mode++;
			break;
		}
		case (20) :
		{
			mode_sign = StandbyMode;
			//lowpower_mode++;
			break;
		}
		case (30):
		{
			lowpower_mode = 0;
			mode_sign = SportMode;
			break;
		}
		default:
		{
			//lowpower_mode++;
			break;
		}
	}
	Mode_Choice(mode_sign);
}

void PWR_Init(void)
{
	WKUP_Init();
}

